public class MainRental {
    public static void main(String[] args) {
         new Receipt(19, "Kyle Albeos", "Kyle ALbeos", 190, "Basak Ibna", "19843JHSBN");         // int price, String carName, String name, String contact, String address, String license
    }
    
}
