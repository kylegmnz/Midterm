
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Vehicle1 extends JFrame implements ActionListener{
   int count = 0;
   int mustang = 0;
 
   int vios = 0;
   int price = 0;
   String name,address,lic;
   int age;
   String finalCarName = "No name";
   Font title = new Font("Arial", Font.BOLD, 40);
   Font des = new Font("Arial", Font.BOLD, 25);
   JButton lblMustang = new JButton("Mustang Models");
   
   JButton lblVios = new JButton("Vios Models");
   JPanel background = new JPanel();
   JPanel top = new JPanel();
   JButton next = new JButton("Next");
   JButton back = new JButton("Back");
   JLabel lbltop = new JLabel("SEAN's VEHICLES");
   JButton rent = new JButton("Rent");
   JLabel result = new JLabel();
   JLabel lblprice = new JLabel();
   JLabel lblCarName = new JLabel();
   
//SCALED IMAGES --------------------------------------------------------
   //MUSTANG FIRST PICTURE 
   ImageIcon oldMustang1 = new ImageIcon("mustang1.png");
   Image updateMustang1 = oldMustang1.getImage().getScaledInstance(500,500, Image.SCALE_SMOOTH);
   ImageIcon newMustang1 = new ImageIcon(updateMustang1);
   JLabel imgMustang1 = new JLabel(newMustang1); 
   //MUSTANG SECOND PICTURE
   ImageIcon oldMustang2 = new ImageIcon("mustang2.png");
   Image updateMustang2 = oldMustang2.getImage().getScaledInstance(500,500, Image.SCALE_SMOOTH);
   ImageIcon newMustang2 = new ImageIcon(updateMustang2);
   JLabel imgMustang2 = new JLabel(newMustang2);
   //MUSTANG THIRD PICTURE
   ImageIcon oldMustang3 = new ImageIcon("mustang3.png");
   Image updateMustang3 = oldMustang3.getImage().getScaledInstance(500,500, Image.SCALE_SMOOTH);
   ImageIcon newMustang3 = new ImageIcon(updateMustang3);
   JLabel imgMustang3 = new JLabel(newMustang3);
      
   //VIOS FIRST PICTURE 
   ImageIcon oldVios1 = new ImageIcon("vios1.png");
   Image updateVios1 = oldVios1.getImage().getScaledInstance(500,500, Image.SCALE_SMOOTH);
   ImageIcon newVios1 = new ImageIcon(updateVios1);
   JLabel imgVios1 = new JLabel(newVios1); 
   //VIOS SECOND PICTURE
   ImageIcon oldVios2 = new ImageIcon("vios2.png");
   Image updateVios2 = oldVios2.getImage().getScaledInstance(500,500, Image.SCALE_SMOOTH);
   ImageIcon newVios2 = new ImageIcon(updateVios2);
   JLabel imgVios2 = new JLabel(newVios2);
   //VIOS THIRD PICTURE
   ImageIcon oldVios3 = new ImageIcon("vios3.png");
   Image updateVios3 = oldVios3.getImage().getScaledInstance(500,500, Image.SCALE_SMOOTH);
   ImageIcon newVios3 = new ImageIcon(updateVios3);
   JLabel imgVios3 = new JLabel(newVios3);
   

   
   
   
public Vehicle1(String name, int age, String address, String lic){
super("Vehicle List");
   this.name = name;
   this.age  = age;
   this.address = address;
   this.lic = lic;
   
   setIconImage(oldMustang1.getImage());
   setSize(1000,600);
   setLocationRelativeTo(null);
   setLayout(null);
   setResizable(false);
   setMaximumSize(new Dimension(1000, 600));
   getContentPane().setBackground(new Color(184,190,195));
   vehComponent();
   setVisible(true);
   setDefaultCloseOperation(EXIT_ON_CLOSE);
   
   }


   
public void vehComponent(){
// ADDDDDSS COMPONENTS
//---------------------------------------------------      
//Label Add to JFRAME 
     add(lbltop);
     add(result);
     add(lblprice);
     
// Button Add to Jframe
     add(lblMustang);
   
     add(lblVios);
     add(next);
     add(back);
     add(rent);
     add(lblCarName);
     
//Panels add
     add(top);
     
     
//Images add to JFRAME
     
     
//Modifying added components to JFRAME 
//---------------------------------------------------
//FONTS
     lbltop.setFont(title);
     lblprice.setFont(des);
     lblCarName.setFont(des);
//Labels
     lbltop.setBounds(20, 0, 1000, 70);
     result.setBounds(350, 50, 500, 500);
     lblprice.setBounds(550, 220, 500, 500);
     lblCarName.setBounds(500, 150, 1000, 70);

//Images
     imgMustang1.setBounds(350, 100, 500, 500);
     imgMustang2.setBounds(350, 100, 500, 500);
     imgMustang3.setBounds(350, 100, 500, 500);
  
     imgVios1.setBounds(350, 100, 500, 500);
     imgVios2.setBounds(350, 100, 500, 500);
     imgVios3.setBounds(350, 100, 500, 500);
//Panel1
     top.setBackground(new Color(210,75,75));
     top.setBounds(0, 0, 1000, 70);
//Buttons
     lblMustang.setBounds(10, 110, 150, 30);

     lblVios.setBounds(10, 250, 150, 30);
     next.setBounds(700, 500, 150, 30);
     back.setBounds(300, 500, 150, 30);
     rent.setBounds(500, 500, 150, 30);
     lblMustang.setSize(200,50);

     lblVios.setSize(200,50);
     next.setSize(200,50);
     back.setSize(200,50);
     rent.setSize(200,50);
//Buttons Triggers
     lblMustang.addActionListener(this);
  
     lblVios.addActionListener(this);
     next.addActionListener(this);
     back.addActionListener(this);
     rent.addActionListener(this);
// SETTING COLORS TEXT
   // lblprice.setForeground(new Color(24,188,35));
   lblCarName.setForeground(Color.BLACK);
}

  @Override
public void actionPerformed(ActionEvent e) {
    Object source = e.getSource();
    lblCarName.setText("");
    lblprice.setText("");

    if (source == lblMustang) {
       //  result.setText("Mustang");
        
        mustang = 1;
    
        vios = 0;  
        updateImages();}
    else if (source == lblVios) {
       //  result.setText("Vios");
        mustang = 0;
       
        vios = 1;
        updateImages(); 

    } else if (source == next || source == back) {
        
        if (source == next) {
            count++;
        } else if (source == back) {
            count--;
        }

      
        if (count > 3) {
            count = 1;
        } else if (count < 1) {
            count = 3;
        }

       
        updateCarImageBasedOnCount();
    } else if (source == rent) {
      dispose();
        result.setText("rent");
        
        String carName = finalCarName;
        new Reciept(price, carName, name , age, address, lic);
        
    }
}

private void updateImages() {
    
    remove(imgMustang1);
    remove(imgMustang2);
    remove(imgMustang3);
    remove(imgVios1);
    remove(imgVios2);
    remove(imgVios3);

    revalidate();
    repaint();
}

private void updateCarImageBasedOnCount() {

    if (mustang == 1) {
        updateImageMustang();
    } else if (vios == 1) {
        updateImageVios();
    }
}

private void updateImageMustang() {

    if (count == 1) {
        lblCarName.setText("Mustang Beos");
        lblprice.setText("$230"); price = 230; finalCarName = "Mustang Beos";
        remove(imgMustang3);
        remove(imgMustang2);
        add(imgMustang1);
    } else if (count == 2) {
        lblCarName.setText("Mustang Jabin's");
        lblprice.setText("$250"); price = 250; finalCarName = "Mustang Jabins's";
        remove(imgMustang3);
        add(imgMustang2);
        remove(imgMustang1);
    } else if (count == 3) {
          lblCarName.setText("Mustang Kient's");
          lblprice.setText("$400"); price = 400; finalCarName = "Mustang Kient's";
        add(imgMustang3);
        remove(imgMustang2);
        remove(imgMustang1);
    }
    revalidate();
    repaint();
}

private void updateImageVios() {

    if (count == 1) {
         lblCarName.setText("Toyota Vios Gray");
         lblprice.setText("$50"); price = 50; finalCarName = "Toyota Vios Gray";
         remove(imgVios3);
        remove(imgVios2);
        add(imgVios1);
    } else if (count == 2) {
      lblCarName.setText("Vios Sean's Black");
      lblprice.setText("$75"); price = 75; finalCarName = "Vios Sean's Black";
        remove(imgVios3);
        add(imgVios2);
        remove(imgVios1);
    } else if (count == 3) {
    lblCarName.setText("Vios Sean's White");
    lblprice.setText("$100"); price = 100; finalCarName = "Vios Sean's White";
        remove(imgVios1);
        remove(imgVios2);
        add(imgVios3);
    }
    revalidate();
    repaint();
}



}