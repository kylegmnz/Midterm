/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/**
 *
 * @author user01
 */
public class Renter extends JFrame implements ActionListener{
    JLabel lblName = new JLabel("Name: ");
    JLabel lblAge = new JLabel("Age: ");
    JLabel lblAddress = new JLabel("Address: ");
    JLabel lblLicense = new JLabel("License: ");
    JLabel lblBudget = new JLabel("Budget: ");
    JTextField txtName = new JTextField();
    JTextField txtAge = new JTextField();
    JTextField txtAddress = new JTextField();
    JTextField txtLicense = new JTextField();
    JTextField txtBudget = new JTextField();
    JButton btnNext = new JButton("Next");
    
    //IMAGE
    ImageIcon oldRental = new ImageIcon("rental.png");
    Image updateRental = oldRental.getImage().getScaledInstance(200,200, Image.SCALE_SMOOTH);
    ImageIcon newRental = new ImageIcon(updateRental);
    JLabel imgRental = new JLabel(newRental);
    
    JLabel lblTitle = new JLabel("SEAN's CAR RENTAL");
    Font font = new Font("Arial", Font.PLAIN, 20);
    
    
    
    public Renter(){
     super("Client Information");
     setSize(300,500);
     setResizable(false);
     setMaximumSize(new Dimension(300, 500));
     setLocationRelativeTo(null);
     setLayout(null);
      getContentPane().setBackground(new Color(184,190,195));
     Components();
     
     setDefaultCloseOperation(EXIT_ON_CLOSE);
     setVisible(true);
     
    }
    // ---- COMPONENTS OF OUR CLIENT JFRAMES --- //
    public void Components(){
        add(lblName);
        add(lblAge);
        add(lblAddress);
        add(lblLicense);
        add(txtName);
        add(txtAge);
        add(txtAddress);
        add(txtLicense);
        add(btnNext);
        add(txtBudget);
        add(lblBudget);
        add(imgRental);
        
        //BOUNDS
        lblName.setBounds(10, 20, 150, 30);   
        lblAge.setBounds(10, 60, 150, 30);    
        lblAddress.setBounds(10, 100, 150, 30);
        lblLicense.setBounds(10, 160, 150, 30);
        txtName.setBounds(80, 20, 150, 30);   
        txtAge.setBounds(80, 60, 150, 30);    
        txtAddress.setBounds(80, 100, 150, 30);
        txtLicense.setBounds(80, 160, 150, 30);  
        txtBudget.setBounds(80, 200, 150, 30);
        lblBudget.setBounds(10, 200, 150, 30);
        btnNext.setBounds(80, 250, 150, 30);
        btnNext.setSize(100,30);
        imgRental.setBounds(0, 230, 300, 300);
        btnNext.addActionListener(this);
    
    }
    
    
    @Override
    public void actionPerformed(ActionEvent e){
      dispose();
      String name = txtName.getText();    
      int age = Integer.parseInt(txtAge.getText());
      String address = txtAddress.getText();
      String lic = txtLicense.getText();
      int budget = Integer.parseInt(txtBudget.getText());
      
      if(budget >= 1000)
      {
      new Vehicle2(name,age,address,lic);
      }else{
         new Vehicle1(name,age,address,lic);
      }
            
    }
    
    
    
}