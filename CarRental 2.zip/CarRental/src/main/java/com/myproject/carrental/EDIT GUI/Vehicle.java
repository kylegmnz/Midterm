//package com.myproject.carrental;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Vehicle extends JFrame implements ActionListener{
   int count = 0;
   int mustang = 0;
   int lambo = 0;
   int vios = 0;
   Font font = new Font("Arial", Font.BOLD, 40);
   JButton lblMustang = new JButton("Mustang Models");
   JButton lblLamborghini = new JButton("Lamborghini Models");
   JButton lblVios = new JButton("Vios Models");
   JPanel background = new JPanel();
   JPanel top = new JPanel();
   JButton next = new JButton("Next");
   JButton back = new JButton("Back");
   JLabel lbltop = new JLabel("SEAN's VEHICLES");
   JButton rent = new JButton("Rent");
   JLabel result = new JLabel("TESTING");
//SCALED IMAGES --------------------------------------------------------
   //MUSTANG FIRST PICTURE 
   ImageIcon oldMustang1 = new ImageIcon("mustang1.png");
   Image updateMustang1 = oldMustang1.getImage().getScaledInstance(500,500, Image.SCALE_SMOOTH);
   ImageIcon newMustang1 = new ImageIcon(updateMustang1);
   JLabel imgMustang1 = new JLabel(newMustang1); 
   //MUSTANG SECOND PICTURE
   ImageIcon oldMustang2 = new ImageIcon("mustang2.png");
   Image updateMustang2 = oldMustang2.getImage().getScaledInstance(500,500, Image.SCALE_SMOOTH);
   ImageIcon newMustang2 = new ImageIcon(updateMustang2);
   JLabel imgMustang2 = new JLabel(newMustang2);
   //MUSTANG THIRD PICTURE
   ImageIcon oldMustang3 = new ImageIcon("mustang3.png");
   Image updateMustang3 = oldMustang3.getImage().getScaledInstance(500,500, Image.SCALE_SMOOTH);
   ImageIcon newMustang3 = new ImageIcon(updateMustang3);
   JLabel imgMustang3 = new JLabel(newMustang3);
   
   //LAMBO FIRST PICTURE 
   ImageIcon oldLambo1 = new ImageIcon("lambo1.png");
   Image updateLambo1 = oldLambo1.getImage().getScaledInstance(500,500, Image.SCALE_SMOOTH);
   ImageIcon newLambo1 = new ImageIcon(updateLambo1);
   JLabel imgLambo1 = new JLabel(newLambo1); 
   //LAMBO SECOND PICTURE
   ImageIcon oldLambo2 = new ImageIcon("lambo2.png");
   Image updateLambo2 = oldLambo2.getImage().getScaledInstance(500,500, Image.SCALE_SMOOTH);
   ImageIcon newLambo2 = new ImageIcon(updateLambo2);
   JLabel imgLambo2 = new JLabel(newLambo2);
   //LAMBO THIRD PICTURE
   ImageIcon oldLambo3 = new ImageIcon("lambo3.png");
   Image updateLambo3 = oldLambo3.getImage().getScaledInstance(500,500, Image.SCALE_SMOOTH);
   ImageIcon newLambo3 = new ImageIcon(updateLambo3);
   JLabel imgLambo3 = new JLabel(newLambo3);
   
   //VIOS FIRST PICTURE 
   ImageIcon oldVios1 = new ImageIcon("vios1.png");
   Image updateVios1 = oldVios1.getImage().getScaledInstance(500,500, Image.SCALE_SMOOTH);
   ImageIcon newVios1 = new ImageIcon(updateVios1);
   JLabel imgVios1 = new JLabel(newVios1); 
   //VIOS SECOND PICTURE
   ImageIcon oldVios2 = new ImageIcon("vios2.png");
   Image updateVios2 = oldVios2.getImage().getScaledInstance(500,500, Image.SCALE_SMOOTH);
   ImageIcon newVios2 = new ImageIcon(updateVios2);
   JLabel imgVios2 = new JLabel(newVios2);
   //VIOS THIRD PICTURE
   ImageIcon oldVios3 = new ImageIcon("vios3.png");
   Image updateVios3 = oldVios3.getImage().getScaledInstance(500,500, Image.SCALE_SMOOTH);
   ImageIcon newVios3 = new ImageIcon(updateVios3);
   JLabel imgVios3 = new JLabel(newVios3);
   

   
   
   
public Vehicle(){
   super("Vehicle List");
   setIconImage(oldMustang1.getImage());
   setSize(1000,600);
   setLocationRelativeTo(null);
   setLayout(null);
   setResizable(false);
   setMaximumSize(new Dimension(300, 500));
   vehComponent();
   setVisible(true);
   setDefaultCloseOperation(EXIT_ON_CLOSE);
   }


   
public void vehComponent(){
// ADDDDDSS COMPONENTS
//---------------------------------------------------      
//Label Add to JFRAME 
     add(lbltop);
     add(result);
     
// Button Add to Jframe
     add(lblMustang);
     add(lblLamborghini);
     add(lblVios);
     add(next);
     add(back);
     add(rent);
     
//Panels add
     add(top);
     
     
//Images add to JFRAME
     
     
//Modifying added components to JFRAME 
//---------------------------------------------------
//FONTS
     lbltop.setFont(font);
//Labels
     background.setBackground(Color.CYAN);
     background.setBounds(0,0, 400,500);
     lbltop.setBounds(0, 0, 1000, 70);
     result.setBounds(350, 50, 500, 500);
//Images
     imgMustang1.setBounds(350, 100, 500, 500);
     imgMustang2.setBounds(350, 100, 500, 500);
     imgMustang3.setBounds(350, 100, 500, 500);
     imgLambo1.setBounds(350, 100, 500, 500);
     imgLambo2.setBounds(350, 100, 500, 500);
     imgLambo3.setBounds(350, 100, 500, 500);
     imgVios1.setBounds(350, 100, 500, 500);
     imgVios2.setBounds(350, 100, 500, 500);
     imgVios3.setBounds(350, 100, 500, 500);
//Panel1
     top.setBackground(new Color(210,75,75));
     top.setBounds(0, 0, 1000, 70);
//Buttons
     lblMustang.setBounds(10, 110, 150, 30);
     lblLamborghini.setBounds(10, 150, 150, 30);
     lblVios.setBounds(10, 200, 150, 30);
     next.setBounds(700, 500, 150, 30);
     back.setBounds(300, 500, 150, 30);
     rent.setBounds(500, 500, 150, 30);
//Buttons Triggers
     lblMustang.addActionListener(this);
     lblLamborghini.addActionListener(this);
     lblVios.addActionListener(this);
     next.addActionListener(this);
     back.addActionListener(this);
     rent.addActionListener(this);
}

  @Override
public void actionPerformed(ActionEvent e) {
    Object source = e.getSource();

    if (source == lblMustang) {
        result.setText("Mustang");
        mustang = 1;
        lambo = 0;
        vios = 0;  
        updateImages(); 
    } else if (source == lblLamborghini) {
        result.setText("Lambo");
        mustang = 0;
        lambo = 1;
        vios = 0; 
        updateImages(); 
    } else if (source == lblVios) {
        result.setText("Vios");
        mustang = 0;
        lambo = 0;
        vios = 1;
        updateImages(); 
    } else if (source == next || source == back) {
        
        if (source == next) {
            count++;
        } else if (source == back) {
            count--;
        }

      
        if (count > 3) {
            count = 1;
        } else if (count < 1) {
            count = 3;
        }

       
        updateCarImageBasedOnCount();
    } else if (source == rent) {
        result.setText("rent");
    }
}

private void updateImages() {
    
    remove(imgMustang1);
    remove(imgMustang2);
    remove(imgMustang3);
    remove(imgLambo1);
    remove(imgLambo2);
    remove(imgLambo3);
    remove(imgVios1);
    remove(imgVios2);
    remove(imgVios3);

    revalidate();
    repaint();
}

private void updateCarImageBasedOnCount() {

    if (mustang == 1) {
        updateImageMustang();
    } else if (lambo == 1) {
        updateImageLambo();
    } else if (vios == 1) {
        updateImageVios();
    }
}

private void updateImageMustang() {

    if (count == 1) {
        remove(imgMustang3);
        remove(imgMustang2);
        add(imgMustang1);
    } else if (count == 2) {
        remove(imgMustang3);
        add(imgMustang2);
        remove(imgMustang1);
    } else if (count == 3) {
        add(imgMustang3);
        remove(imgMustang2);
        remove(imgMustang1);
    }
    revalidate();
    repaint();
}

private void updateImageLambo() {
 
    if (count == 1) {
         remove(imgLambo3);
        remove(imgLambo2);
        add(imgLambo1);
    } else if (count == 2) {
         remove(imgLambo3);
        add(imgLambo2);
        remove(imgLambo1);
    } else if (count == 3) {
         add(imgLambo3);
        remove(imgLambo2);
        remove(imgLambo1);
    }
    revalidate();
    repaint();
}

private void updateImageVios() {

    if (count == 1) {
         remove(imgVios3);
        remove(imgVios2);
        add(imgVios1);
    } else if (count == 2) {
        remove(imgVios3);
        add(imgVios2);
        remove(imgVios1);
    } else if (count == 3) {
        remove(imgVios1);
        remove(imgVios2);
        add(imgVios3);
    }
    revalidate();
    repaint();
}



}