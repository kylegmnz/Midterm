package com.myproject.carrental;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Vehicle extends JFrame{
   private Renter rent;
   JLabel lblFerrari = new JLabel("Ferrari");
   JLabel lblLamborghini = new JLabel("Lamborghini");
   
   
public Vehicle(){
   super("Vehicle List");
   setSize(300,500);
   setLocationRelativeTo(null);
   setLayout(null);
   vehComponent();
   setVisible(true);
   setDefaultCloseOperation(EXIT_ON_CLOSE);
   }
   
   
public void vehComponent(){
   
     add(lblFerrari);
     add(lblLamborghini);
     lblFerrari.setBounds(80, 100, 150, 30);
     lblLamborghini.setBounds(80, 130, 150, 30);
     
   
}

}