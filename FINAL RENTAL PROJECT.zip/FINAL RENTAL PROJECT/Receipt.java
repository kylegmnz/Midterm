import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Date;
import java.util.ArrayList;

public class Receipt extends JFrame{


   String today = new Date().toString();
   Font title = new Font("Arial", Font.BOLD, 40);
   Font des = new Font("Arial", Font.BOLD, 25);
   Font small = new Font("Arial", Font.BOLD, 17);
   Font infoFont = new Font("Arial", Font.BOLD, 17);
   
   
   JPanel receipt = new JPanel();
   JLabel lblreceipt = new JLabel("RECEIPT");
   JLabel lbltitle = new JLabel("SEAN's RENTAL RECEIPT");
   JLabel lblcarName = new JLabel();
   JLabel lblprice = new JLabel();
   JLabel lblUserName;
   JLabel lblContact;
   JLabel lblAddress;
   JLabel lblLicense;
   JLabel lblRentFee;
   JLabel date = new JLabel(today);
   JLabel info = new JLabel("A weekly charge covered within two months' rent.");
   
   //IMAGE
   ImageIcon oldProof = new ImageIcon("verify.png");
    Image updateProof = oldProof.getImage().getScaledInstance(250,250, Image.SCALE_SMOOTH);
   ImageIcon newProof = new ImageIcon(updateProof);
   JLabel imgProof = new JLabel(newProof);
   
   //CONSTRUCTOR
   public Receipt(int price, String carName, String name, int contact, String address, String license){
      super("Receipt");
      String fileName = "user.txt";        
      String[] nameArray = ArrayListSaver.loadNames(fileName);
      
      String[] newNameArray = ArrayListSaver.append(nameArray, name);
      ArrayListSaver.saveNames(newNameArray, fileName);
      setSize(700,600);
      setLocationRelativeTo(null); 
        setResizable(false);
   setMaximumSize(new Dimension(700, 600));
       getContentPane().setBackground(new Color(184,190,195));
      setLayout(null);
      lblUserName = new JLabel("Name: " + name);
      lblContact = new JLabel("Contact: "+ contact);
      lblAddress = new JLabel("Address: " + address);
      lblLicense = new JLabel("License: "+license);
      int Fee = CalculateFee(price); 
      String totalFee = String.valueOf(Fee);
      lblRentFee = new JLabel("Rent Fee: $"+ totalFee);
      Components(price,carName);
      
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setVisible(true);
   }


   public void Components(int price, String carName){
// ADDING COMPONENTS AREA 
//JFrame
      add(lblcarName);
      add(lblprice);
      add(receipt);
      add(lbltitle);
      add(lblUserName);
      add(lblContact);
      add(lblAddress);
      add(lblLicense);
      add(lblRentFee);
      add(imgProof);
      add(date);
      add(info);
      
//SETTING LABELS
      lblcarName.setText(carName);
      lblprice.setText("Price: $"+(String.valueOf(price)));
      

// JPanel
      receipt.setBackground(new Color(236,84,84));
      receipt.add(lblreceipt);
// Buttons

// Fonts
     lblreceipt.setFont(title);
     lbltitle.setFont(title);
     lblcarName.setFont(title);
     lblprice.setFont(des);
     lblRentFee.setFont(des);
     date.setFont(des);
     info.setFont(small);
     lblUserName.setFont(small);
     lblContact.setFont(small);
     lblAddress.setFont(small);
     lblLicense.setFont(small);
// Layouts
     lblcarName.setBounds(10, 250, 500, 70);
     lblprice.setBounds(10, 300, 500, 70);
     lblreceipt.setBounds(10, 0, 500, 70);
     receipt.setBounds(0, 150, 700, 70);
     lbltitle.setBounds(100, 0, 1000, 70);
     lblUserName.setBounds(10, 40, 1000, 70);
     lblContact.setBounds(10, 60, 1000, 70);
     lblAddress.setBounds(10, 80, 1000, 70);
     lblLicense.setBounds(10, 100, 1000, 70);
     lblRentFee.setBounds(10, 350, 500, 70);
     imgProof.setBounds(450, 380, 250, 250);
     date.setBounds(10, 400, 500, 70);
     info.setBounds(10, 500, 500, 70);


   
     
     
     
   }



public int CalculateFee(int price){
   if(price == 0){
      return 0;
      
   }else{
   
   int baseFee = price * 8;
   int insuranceFee = 50 * 8;
   int totalRentFee = baseFee + insuranceFee + 150;
   
   return totalRentFee;
   }
}
}