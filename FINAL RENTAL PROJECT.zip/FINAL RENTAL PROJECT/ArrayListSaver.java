import java.io.*;
import java.util.Arrays;

public class ArrayListSaver{

    public static String[] loadNames(String fileName) {
        String[] names = new String[0]; 
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                names = append(names, line);
            }
        } catch (IOException e) {
                    }
        return names;
    }

        public static String[] append(String[] arr, String newName) {
        String[] newArray = Arrays.copyOf(arr, arr.length + 1);
        newArray[arr.length] = newName;
        return newArray;
    }
        public static void saveNames(String[] nameArray, String fileName) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (String name : nameArray) {
                writer.write(name);
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving names: " + e.getMessage());
        }
    }
}