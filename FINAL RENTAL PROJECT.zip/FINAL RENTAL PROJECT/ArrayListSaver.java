import java.io.*;
import java.util.ArrayList;

public class ArrayListSaver {

    
    public static void saveArrayList(ArrayList<String> list, String fileName) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(list);
            System.out.println("ArrayList saved to file: " + fileName);
        } catch (IOException e) {
            System.err.println("Error saving ArrayList: " + e.getMessage());
        }
    }

  
    public static ArrayList<String> loadArrayList(String fileName) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) {
            return (ArrayList<String>) ois.readObject();  
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading ArrayList: " + e.getMessage());
            return new ArrayList<>();  
        }
    }
}