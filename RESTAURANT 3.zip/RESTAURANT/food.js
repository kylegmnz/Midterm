const country_foods = document.getElementById('country-foods');
const imgBanner =  document.getElementById('imgBanner');
const imgTitle = document.getElementById('imgTitle');
const topColor = document.getElementById('top');
const imgFlag = document.getElementById('imgFlag');

// IMG OF FOOD
const img_food1 = document.getElementById('img-food1');
const img_food2 = document.getElementById('img-food2');
const img_food3 = document.getElementById('img-food3');
const img_food4 = document.getElementById('img-food4');
const img_food5 = document.getElementById('img-food5');
const img_food6 = document.getElementById('img-food6');
const img_food7 = document.getElementById('img-food7');
const img_food8 = document.getElementById('img-food8');
// TITLE FO FOOD
const h3_food1 = document.getElementById('h3-food1');
const h3_food2 = document.getElementById('h3-food2');
const h3_food3 = document.getElementById('h3-food3');
const h3_food4 = document.getElementById('h3-food4');
const h3_food5 = document.getElementById('h3-food5');
const h3_food6 = document.getElementById('h3-food6');
const h3_food7 = document.getElementById('h3-food7');
const h3_food8 = document.getElementById('h3-food8');
// FLAG OF FOOD
const flag_food1 = document.getElementById('flag-food1');
const flag_food2 = document.getElementById('flag-food2');
const flag_food3 = document.getElementById('flag-food3');
const flag_food4 = document.getElementById('flag-food4');
const flag_food5 = document.getElementById('flag-food5');
const flag_food6 = document.getElementById('flag-food6');
const flag_food7 = document.getElementById('flag-food7');
const flag_food8 = document.getElementById('flag-food8');

// PARAGRAPH OF FOOD
const food_p1 = document.getElementById('food-p1');
const food_p2 = document.getElementById('food-p2');
const food_p3 = document.getElementById('food-p3');
const food_p4 = document.getElementById('food-p4');
const food_p5 = document.getElementById('food-p5');
const food_p6 = document.getElementById('food-p6');
const food_p7 = document.getElementById('food-p7');
const food_p8 = document.getElementById('food-p8');
const href_2 = document.getElementById('href-2');



country_foods.addEventListener('change', () => {
    const foods = country_foods.value;
    switch(foods){
        
        case 'philippines':
            imgTitle.textContent = "Bicol Express";
            imgBanner.src = "images/bicol.jpg";
            topColor.style.backgroundColor = "rgb(41, 38, 38)";
            imgFlag.src = "images/philippines.jpg";
//FLAG OF FOOD 
            flag_food1.src = "images/philippines.jpg";
            flag_food2.src = "images/philippines.jpg";
            flag_food3.src = "images/philippines.jpg";
            flag_food4.src = "images/philippines.jpg";
            flag_food5.src = "images/philippines.jpg";
            flag_food6.src = "images/philippines.jpg";
            flag_food7.src = "images/philippines.jpg";
            flag_food8.src = "images/philippines.jpg";

            //TITLE OF FOOD
            h3_food1.textContent = "Chicken Adobo";
            h3_food2.textContent = "Kare-Kare";
            h3_food3.textContent = "Bicol Express";
            h3_food4.textContent = "Inasal";
            h3_food5.textContent = "Bulalo";
            h3_food6.textContent = "Humba";
            h3_food7.textContent = "Caldereta";
            h3_food8.textContent = "Sinigang";


// IMG OF FOOD
            img_food1.src = "images/PH/chicken-adobo.png";
            img_food2.src = "images/PH/Kare-Kare.png";
            img_food3.src = "images/PH/Bicol-Express.png";
            img_food4.src = "images/PH/Inasal.png";
            img_food5.src = "images/PH/Bulalo.png";
            img_food6.src = "images/PH/Humba.png";
            img_food7.src = "images/PH/Caldereta.png";
            img_food8.src = "images/PH/Sinigang.png";

// PARAGRAPH
            food_p1.textContent = "Chicken Adobo is a Filipino dish made by marinating chicken in soy sauce, vinegar, garlic, and spices, then simmering it until tender.";
            food_p2.textContent = "Kare-Kare is a traditional Filipino dish known for its rich, savory peanut sauce.";
            food_p3.textContent = "Bicol Express is a popular Filipino dish originating from the Bicol region of the Philippines.";
            food_p4.textContent = "Inasal is a Filipino grilled chicken dish marinated in vinegar, soy sauce, garlic, and spices, typically served with rice.";
            food_p5.textContent = "Bulalo is a Filipino beef soup made with shank and bone marrow, simmered for hours to create a rich, savory broth.";
            food_p6.textContent = "Humba is a Filipino braised pork dish, often considered a sweeter and richer variation of adobo.";
            food_p7.textContent = "Caldereta is a rich Filipino beef stew, traditionally made with beef brisket or beef shank.";
            food_p8.textContent = "Sinigang is a traditional Filipino sour soup or stew, beloved for its tangy, savory flavor.";


            break;
            case 'japan':
                imgTitle.textContent = "Ramen";
                imgBanner.src = "images/japan.png";
                topColor.style.backgroundColor = "rgb(197, 2, 2)";
                imgFlag.src = "images/fjapan.jpg";
//FLAG OF FOOD 
                flag_food1.src = "images/fjapan.jpg";
                flag_food2.src = "images/fjapan.jpg";
                flag_food3.src = "images/fjapan.jpg";
                flag_food4.src = "images/fjapan.jpg";
                flag_food5.src = "images/fjapan.jpg";
                flag_food6.src = "images/fjapan.jpg";
                flag_food7.src = "images/fjapan.jpg";
                flag_food8.src = "images/fjapan.jpg";
                


//TITLE OF FOOD
                h3_food1.textContent = "Ramen";
                h3_food2.textContent = "Yakitori";
                h3_food3.textContent = "Takoyaki";
                h3_food4.textContent = "Tamagoyaki";
                h3_food5.textContent = "Okonomiyaki";
                h3_food6.textContent = "Gyoza";
                h3_food7.textContent = "Curry Bread";
                h3_food8.textContent = "Chawanmushi";


// IMG OF FOOD
                img_food1.src = "images/JAPAN/Ramen.png";
                img_food2.src = "images/JAPAN/Yakitori.png";
                img_food3.src = "images/JAPAN/Takoyaki.png";
                img_food4.src = "images/JAPAN/Tamagoyaki.png";
                img_food5.src = "images/JAPAN/Okonomiyak.png";
                img_food6.src = "images/JAPAN/Gyoza.png";
                img_food7.src = "images/JAPAN/Curry Bread.png";
                img_food8.src = "images/JAPAN/Chawanmushi.png";

// PARAGRAPH
                food_p1.textContent = "Ramen is a Japanese noodle soup with a flavorful broth, noodles, and various toppings like pork and eggs.";
                food_p2.textContent = "Yakitori is a Grilled skewers of chicken, often served with tare sauce or salt.";
                food_p3.textContent = "Takoyaki is Savory Japanese dumplings made with batter and filled with octopus, topped with sauce and bonito flakes.";
                food_p4.textContent = "Tamagoyaki is a rolled Japanese omelette made from layered, seasoned eggs.";
                food_p5.textContent = "Okonomiyaki is a savory Japanese pancake with cabbage, batter, and optional meat or seafood, topped with sauce and bonito flakes.";
                food_p6.textContent = "Gyoza is a Japanese dumplings filled with ground meat and vegetables, often pan-fried.";
                food_p7.textContent = "Curry Bread is a deep-fried bread filled with Japanese curry.";
                food_p8.textContent = "Chawanmushi is a savory steamed egg custard dish with meat and vegetables.";


                break;
                case 'korea':
                    imgTitle.textContent = "Jjajangmyeon";
                    imgBanner.src = "images/korea-banner.png";
                    topColor.style.backgroundColor = "rgb(22, 2, 2)";
                    imgFlag.src = "images/korea.jpg";
                    //FLAG OF FOOD 
                                    flag_food1.src = "images/korea.jpg";
                                    flag_food2.src = "images/korea.jpg";
                                    flag_food3.src = "images/korea.jpg";
                                    flag_food4.src = "images/korea.jpg";
                                    flag_food5.src = "images/korea.jpg";
                                    flag_food6.src = "images/korea.jpg";
                                    flag_food7.src = "images/korea.jpg";
                                    flag_food8.src = "images/korea.jpg";
                                    
                    
                    
                    //TITLE OF FOOD
                                    h3_food1.textContent = "Kongguksu";
                                    h3_food2.textContent = "Odeng";
                                    h3_food3.textContent = "Bibimbap";
                                    h3_food4.textContent = "Bulgogi";
                                    h3_food5.textContent = "Galbi";
                                    h3_food6.textContent = "Hobakjeon";
                                    h3_food7.textContent = "Japchae";
                                    h3_food8.textContent = "Tteokguk";
                    
                    
                    // IMG OF FOOD
                                    img_food1.src = "images/KOREA/ Kongguksu.png";
                                    img_food2.src = "images/KOREA/odeng.png";
                                    img_food3.src = "images/KOREA/Bibimbap.png";
                                    img_food4.src = "images/KOREA/Bulgogi.png";
                                    img_food5.src = "images/KOREA/Galbi.png";
                                    img_food6.src = "images/KOREA/Hobakjeon.png";
                                    img_food7.src = "images/KOREA/Japchae.png";
                                    img_food8.src = "images/KOREA/Tteokguk.png";
                    
                    
                    // PARAGRAPH
                                    food_p1.textContent = "Kongguksu is a traditional Korean cold noodle dish served in a chilled soybean broth.";
                                    food_p2.textContent = "Odeng is a versatile ingredient in Korean cuisine and is often served as street food, snacks, or in soups and stews.";
                                    food_p3.textContent = "Bibimbap is one of the most iconic Korean dishes, meaning mixed rice.";
                                    food_p4.textContent = "Bulgogi is a beloved Korean dish made with thinly sliced, marinated beef that's grilled, stir-fried, or cooked on a barbecue.";
                                    food_p5.textContent = "Galbi is a popular dish made from marinated beef or pork short ribs that are grilled or barbecued.";
                                    food_p6.textContent = "Hobakjeon is a classic Korean dish consisting of pan-fried zucchini slices that are lightly coated in flour and egg.";
                                    food_p7.textContent = "Japchae is a popular Korean stir-fried noodle dish made with glass noodles (dangmyeon), vegetables, and often a choice of protein.";
                                    food_p8.textContent = "Tteokguk is a traditional Korean soup made with sliced rice cakes (tteok) in a savory beef or anchovy-based broth.";
                    break;
                    case 'china':
                        imgTitle.textContent = "Xiaolongbao";
                    imgBanner.src = "images/china-banenr.png";
                    topColor.style.backgroundColor = "rgb(22, 2, 2)";
                    imgFlag.src = "images/china.jpg";
                    //FLAG OF FOOD 
                                    flag_food1.src = "images/china.jpg";
                                    flag_food2.src = "images/china.jpg";
                                    flag_food3.src = "images/china.jpg";
                                    href_2.href = "ingredients.html#box11-img";
                                    flag_food4.src = "images/china.jpg";
                                    flag_food5.src = "images/china.jpg";
                                    flag_food6.src = "images/china.jpg";
                                    flag_food7.src = "images/china.jpg";
                                    flag_food8.src = "images/china.jpg";
                                    
                    
                    
                    //TITLE OF FOOD
                                    h3_food1.textContent = "Chow Mein";
                                    h3_food2.textContent = "Hot Pot";
                                    h3_food3.textContent = "Jianbing";
                                    h3_food4.textContent = "Kung Pao";
                                    h3_food5.textContent = "Mapo Tofu";
                                    h3_food6.textContent = "Roasted Duck";
                                    h3_food7.textContent = "Sour Pork";
                                    h3_food8.textContent = "Xiaolongbao";

                    
                    
                    // IMG OF FOOD
                                    img_food1.src = "images/CHINA/chow-mein.png";
                                    img_food1.style.transform = "rotateX(180deg)";
                                    img_food2.src = "images/CHINA/Hot-pot.png";
                                    img_food3.src = "images/CHINA/Jianbing.png";
                                    img_food4.src = "images/CHINA/Kung-Pao.png";
                                    img_food5.src = "images/CHINA/Mapo-Tofu.png";
                                    img_food6.src = "images/CHINA/roasted-duck.png";
                                    img_food7.src = "images/CHINA/sour-pork.png";
                                    img_food8.src = "images/CHINA/Xiaolongbao.png";
                    
                    
                    // PARAGRAPH
                                    food_p1.textContent = "Chow Mein is a Chinese stir-fried noodle dish, typically made with vegetables, meat, and soy sauce.";
                                    food_p2.textContent = "Hot Pot is a Chinese communal dish where ingredients like meat, seafood, and vegetables are cooked in a simmering pot of broth at the table.";
                                    food_p3.textContent = "Jianbing is a Chinese street food, often described as a savory crepe filled with egg, herbs, vegetables, and various fillings.";
                                    food_p4.textContent = "Kung Pao is a spicy Chinese stir-fry dish made with chicken, peanuts, and vegetables, flavored with soy sauce, vinegar, and chili peppers.";
                                    food_p5.textContent = "Mapo Tofu is a Sichuan dish made with tofu in a spicy, savory sauce with ground pork or beef, flavored with chili bean paste and Sichuan peppercorns.";
                                    food_p6.textContent = "Roasted Duck is a Chinese dish known for its crispy skin and tender meat, often served with pancakes, hoisin sauce, and scallions.";
                                    food_p7.textContent = "Sour Pork is a dish popular in Chinese cuisine, especially in regions like Guangdong, and is often characterized by its unique sweet and sour flavor profile.";
                                    food_p8.textContent = "Xiaolongbao is a traditional Chinese soup dumplings that originate from Shanghai.";
                        break;
                        case 'italy':
                            imgTitle.textContent = "Lasagna";
                    imgBanner.src = "images/Lasagna.png";
                    topColor.style.backgroundColor = "rgb(22, 2, 2)";
                    imgFlag.src = "images/italy.jpg";
                    //FLAG OF FOOD 
                                    flag_food1.src = "images/italy.jpg";
                                    flag_food2.src = "images/italy.jpg";
                                    flag_food3.src = "images/italy.jpg";
                                    flag_food4.src = "images/italy.jpg";
                                    flag_food5.src = "images/italy.jpg";
                                    flag_food6.src = "images/italy.jpg";
                                    flag_food7.src = "images/italy.jpg";
                                    flag_food8.src = "images/italy.jpg";
                                    
                    
                    
                    //TITLE OF FOOD
                                    h3_food1.textContent = "Bruschetta";
                                    h3_food2.textContent = "Panzanella";
                                    h3_food3.textContent = "Pasta Carbonara";
                                    h3_food4.textContent = "Pizza Margherita";
                                    h3_food5.textContent = "Prosciutto";
                                    h3_food6.textContent = "Risotto";
                                    h3_food7.textContent = "Tiramisu";
                                    h3_food8.textContent = "Lasagna";

                    
                    
                    // IMG OF FOOD
                                    img_food1.src = "images/ITALY/Bruschetta.png";
                                    img_food2.src = "images/ITALY/Panzanella.png";
                                    img_food3.src = "images/ITALY/Pasta-Carbonara.png";
                                    img_food4.src = "images/ITALY/pizza-margherita.png";
                                    img_food5.src = "images/ITALY/Prosciutto.png";
                                    img_food6.src = "images/ITALY/risotto.png";
                                    img_food7.src = "images/ITALY/Tiramisu.png";
                                    img_food8.src = "images/ITALY/LASAGNA.png";
                    
                    
                    // PARAGRAPH
                                    food_p1.textContent = "Bruschetta is a Italian appetizer consisting of toasted bread topped with diced tomatoes, garlic, basil, and olive oil.";
                                    food_p2.textContent = "Panzanella is a Italian salad made with soaked bread, tomatoes, cucumbers, onions, and olive oil.";
                                    food_p3.textContent = "Pasta Carbonara is a Italian pasta dish made with eggs, cheese (typically Pecorino Romano), pancetta, and black pepper.";
                                    food_p4.textContent = "Pizza Margherita is a traditional Italian pizza topped with tomato, mozzarella, fresh basil, and olive oil.";
                                    food_p5.textContent = "Prosciutto is an Italian dry-cured ham, often served thinly sliced and uncooked.";
                                    food_p6.textContent = "Risotto is a Italian creamy rice dish cooked with broth, butter, and often flavored with cheese, vegetables, or meat.";
                                    food_p7.textContent = "Tiramisu is a Italian dessert made of coffee-soaked ladyfingers, mascarpone cheese, cocoa powder, and a powder of chocolate.";
                                    food_p8.textContent = "Lasagna is a Italian pasta dish made with layers of pasta, meat sauce, cheese, and béchamel, then baked until golden.";


                            break;
        
    }
});

