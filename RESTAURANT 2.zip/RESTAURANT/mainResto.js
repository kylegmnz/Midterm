const local_global = document.getElementById('local-global');
const local = document.getElementById('local');
const global = document.getElementById('global');
const neym1 = document.getElementById('imgneym1');
const neym2 = document.getElementById('imgneym2');
const neym3 = document.getElementById('imgneym3');
const neym4 = document.getElementById('imgneym4');
const neym5 = document.getElementById('imgneym5');
const neym6 = document.getElementById('imgneym6');

const neym1p = document.getElementById('neym1-p');
const neym2p = document.getElementById('neym2-p');
const neym3p = document.getElementById('neym3-p');
const neym4p = document.getElementById('neym4-p');
const neym5p = document.getElementById('neym5-p');
const neym6p = document.getElementById('neym6-p');

local_global.addEventListener('change', () => {
    const choice = local_global.value;

    switch(choice){
        case 'local':
            neym1p.textContent = "Fresh Lumpia";
            neym1.src = "images/lumpia.png";
            neym2p.textContent = "Sisig";
            neym2.src = "images/sisig.png";
            neym3p.textContent = "Pork Paig";
            neym3.src = "images/pork.png";
            neym4p.textContent = "Bulalo";
            neym4.src = "images/sinabaw.png";
            neym5p.textContent = "Inasal";
            neym5.src = "images/inasal.png";
            neym6p.textContent = "Chicken Adobo";
            neym6.src = "images/chicken-adobo.png";
            console.log(choice);
            break;
        case 'global':
            neym1p.textContent = "Ice-Cream";
            neym1.src = "images/ice-cream.png";
            neym2p.textContent = "Sushi";
            neym2.src = "images/sushi.png";
            neym3p.textContent = "Chow Pan";
            neym3.src = "images/chowpan.png";
            neym4p.textContent = "Fried Ching";
            neym4.style.transform = "rotate(0deg)";
            neym4.src = "images/fried-ching.png";
            neym5p.textContent = "Burger Italy";
            neym5.src = "images/burger.png";
            neym6p.textContent = "Rabukki";
            neym6.src = "images/Rabukki.png";
            console.log(choice);
        break;
        }
});
