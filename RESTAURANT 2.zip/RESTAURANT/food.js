const country_foods = document.getElementById('country-foods');
const imgBanner =  document.getElementById('imgBanner');
const imgTitle = document.getElementById('imgTitle');
const topColor = document.getElementById('top');
const imgFlag = document.getElementById('imgFlag');

// IMG OF FOOD
const img_food1 = document.getElementById('img-food1');
const img_food2 = document.getElementById('img-food2');
const img_food3 = document.getElementById('img-food3');
const img_food4 = document.getElementById('img-food4');
const img_food5 = document.getElementById('img-food5');
const img_food6 = document.getElementById('img-food6');
const img_food7 = document.getElementById('img-food7');
const img_food8 = document.getElementById('img-food8');
// TITLE FO FOOD
const h3_food1 = document.getElementById('h3-food1');
const h3_food2 = document.getElementById('h3-food2');
const h3_food3 = document.getElementById('h3-food3');
const h3_food4 = document.getElementById('h3-food4');
const h3_food5 = document.getElementById('h3-food5');
const h3_food6 = document.getElementById('h3-food6');
const h3_food7 = document.getElementById('h3-food7');
const h3_food8 = document.getElementById('h3-food8');
// FLAG OF FOOD
const flag_food1 = document.getElementById('flag-food1');
const flag_food2 = document.getElementById('flag-food2');
const flag_food3 = document.getElementById('flag-food3');
const flag_food4 = document.getElementById('flag-food4');
const flag_food5 = document.getElementById('flag-food5');
const flag_food6 = document.getElementById('flag-food6');
const flag_food7 = document.getElementById('flag-food7');
const flag_food8 = document.getElementById('flag-food8');

// PARAGRAPH OF FOOD
const food_p1 = document.getElementById('food-p1');
const food_p2 = document.getElementById('food-p2');
const food_p3 = document.getElementById('food-p3');
const food_p4 = document.getElementById('food-p4');
const food_p5 = document.getElementById('food-p5');
const food_p6 = document.getElementById('food-p6');
const food_p7 = document.getElementById('food-p7');
const food_p8 = document.getElementById('food-p8');




country_foods.addEventListener('change', () => {
    const foods = country_foods.value;
    switch(foods){
        
        case 'philippines':
            imgTitle.textContent = "Bicol Express";
            imgBanner.src = "images/bicol.jpg";
            topColor.style.backgroundColor = "rgb(41, 38, 38)";
            imgFlag.src = "images/philippines.jpg";
//FLAG OF FOOD 
            flag_food1.src = "images/philippines.jpg";
            flag_food2.src = "images/philippines.jpg";
            flag_food3.src = "images/philippines.jpg";
            flag_food4.src = "images/philippines.jpg";
            flag_food5.src = "images/philippines.jpg";
            flag_food6.src = "images/philippines.jpg";
            flag_food7.src = "images/philippines.jpg";
            flag_food8.src = "images/philippines.jpg";
            break;
            case 'japan':
                imgTitle.textContent = "Ramen";
                imgBanner.src = "images/japan.png";
                topColor.style.backgroundColor = "rgb(197, 2, 2)";
                imgFlag.src = "images/fjapan.jpg";
//FLAG OF FOOD 
                flag_food1.src = "images/fjapan.jpg";
                flag_food2.src = "images/fjapan.jpg";
                flag_food3.src = "images/fjapan.jpg";
                flag_food4.src = "images/fjapan.jpg";
                flag_food5.src = "images/fjapan.jpg";
                flag_food6.src = "images/fjapan.jpg";
                flag_food7.src = "images/fjapan.jpg";
                flag_food8.src = "images/fjapan.jpg";
                


//TITLE OF FOOD
                h3_food1.textContent = "BATAK";


// IMG OF FOOD
                img_food1.src = "images/food-lumpia.png";


// PARAGRAPH
                food_p1.textContent = "kaon ta kaon";


                break;
                case 'korea':
                    imgTitle.textContent = "Jjajangmyeon";
                    imgBanner.src = "images/korea-banner.png";
                    topColor.style.backgroundColor = "rgb(22, 2, 2)";
                    imgFlag.src = "images/korea.jpg";
                    //FLAG OF FOOD 
                                    flag_food1.src = "images/korea.jpg";
                                    flag_food2.src = "images/korea.jpg";
                                    flag_food3.src = "images/korea.jpg";
                                    flag_food4.src = "images/korea.jpg";
                                    flag_food5.src = "images/korea.jpg";
                                    flag_food6.src = "images/korea.jpg";
                                    flag_food7.src = "images/korea.jpg";
                                    flag_food8.src = "images/korea.jpg";
                                    
                    
                    
                    //TITLE OF FOOD
                                    h3_food1.textContent = "BATAK";
                    
                    
                    // IMG OF FOOD
                                    img_food1.src = "images/food-lumpia.png";
                    
                    
                    // PARAGRAPH
                                    food_p1.textContent = "kaon ta kaon";
                    break;
                    case 'china':
                        imgTitle.textContent = "Jjajangmyeon";
                    imgBanner.src = "images/korea-banner.png";
                    topColor.style.backgroundColor = "rgb(22, 2, 2)";
                    imgFlag.src = "images/korea.jpg";
                    //FLAG OF FOOD 
                                    flag_food1.src = "images/china.jpg";
                                    flag_food2.src = "images/china.jpg";
                                    flag_food3.src = "images/china.jpg";
                                    flag_food4.src = "images/china.jpg";
                                    flag_food5.src = "images/china.jpg";
                                    flag_food6.src = "images/china.jpg";
                                    flag_food7.src = "images/china.jpg";
                                    flag_food8.src = "images/china.jpg";
                                    
                    
                    
                    //TITLE OF FOOD
                                    h3_food1.textContent = "IRO CHIN";
                    
                    
                    // IMG OF FOOD
                                    img_food1.src = "images/iro.png";
                    
                    
                    // PARAGRAPH
                                    food_p1.textContent = "Lami kaayoo";
                        break;
                        case 'italy':
                            
                            break;
        
    }
});

