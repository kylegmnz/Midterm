// foodbox1-ing
// foodbox1-recipe
// BUTTON 1 START
const h2ingredients1 = document.getElementById('h2ingredients1');
const h2ingredients2 = document.getElementById('h2ingredients2');
const h2ingredients3 = document.getElementById('h2ingredients3');
const h2ingredients4 = document.getElementById('h2ingredients4');
const h2ingredients5 = document.getElementById('h2ingredients5');
const h2ingredients6 = document.getElementById('h2ingredients6');
const h2ingredients7 = document.getElementById('h2ingredients7');
const h2ingredients8 = document.getElementById('h2ingredients8');
const h2recipe1 = document.getElementById('h2recipe1');
const h2recipe2 = document.getElementById('h2recipe2');
const h2recipe3 = document.getElementById('h2recipe3');
const h2recipe4 = document.getElementById('h2recipe4');
const h2recipe5 = document.getElementById('h2recipe5');
const h2recipe6 = document.getElementById('h2recipe6');
const h2recipe7 = document.getElementById('h2recipe7');
const h2recipe8 = document.getElementById('h2recipe8');
const recipe1 = document.getElementById('recipe1');
const btning1 = document.getElementById('foodbox1-ing');
const btnrec1 = document.getElementById('foodbox1-recipe');
const rexit1 = document.getElementById('rexit1');
const iexit1 = document.getElementById('iexit1');
const ingredients1 = document.getElementById('ingredients1');
const r1ul1 = document.getElementById('r1ul1');
const r1ul2 = document.getElementById('r1ul2');
const r1ul3 = document.getElementById('r1ul3');
const r1ul4 = document.getElementById('r1ul4');
const r1ul5 = document.getElementById('r1ul5');
const r1ul6 = document.getElementById('r1ul6');
const i1ul1 = document.getElementById('i1ul1');
const i1ul2 = document.getElementById('i1ul2');
const i1ul3 = document.getElementById('i1ul3');
const i1ul4 = document.getElementById('i1ul4');
const i1ul5 = document.getElementById('i1ul5');
const i1ul6 = document.getElementById('i1ul6');

// BUTTON 1 END

// BUTTON 2 START
const recipe2 = document.getElementById('recipe2');
const btning2 = document.getElementById('foodbox2-ing');
const btnrec2 = document.getElementById('foodbox2-recipe');
const rexit2 = document.getElementById('rexit2');
const iexit2 = document.getElementById('iexit2');
const ingredients2 = document.getElementById('ingredients2');
const r2ul1 = document.getElementById('r2ul1');
const r2ul2 = document.getElementById('r2ul2');
const r2ul3 = document.getElementById('r2ul3');
const r2ul4 = document.getElementById('r2ul4');
const r2ul5 = document.getElementById('r2ul5');
const r2ul6 = document.getElementById('r2ul6');
const i2ul1 = document.getElementById('i2ul1');
const i2ul2 = document.getElementById('i2ul2');
const i2ul3 = document.getElementById('i2ul3');
const i2ul4 = document.getElementById('i2ul4');
const i2ul5 = document.getElementById('i2ul5');
const i2ul6 = document.getElementById('i2ul6');

// BUTTON 2 END

// BUTTON 3 STARt
const recipe3 = document.getElementById('recipe3');
const btning3 = document.getElementById('foodbox3-ing');
const btnrec3 = document.getElementById('foodbox3-recipe');
const rexit3 = document.getElementById('rexit3');
const iexit3 = document.getElementById('iexit3');
const ingredients3 = document.getElementById('ingredients3');
const r3ul1 = document.getElementById('r3ul1');
const r3ul2 = document.getElementById('r3ul2');
const r3ul3 = document.getElementById('r3ul3');
const r3ul4 = document.getElementById('r3ul4');
const r3ul5 = document.getElementById('r3ul5');
const r3ul6 = document.getElementById('r3ul6');
const i3ul1 = document.getElementById('i3ul1');
const i3ul2 = document.getElementById('i3ul2');
const i3ul3 = document.getElementById('i3ul3');
const i3ul4 = document.getElementById('i3ul4');
const i3ul5 = document.getElementById('i3ul5');
const i3ul6 = document.getElementById('i3ul6');
// BUTTON 3 END

// BUTTON 4 START
const recipe4 = document.getElementById('recipe4');
const btning4 = document.getElementById('foodbox4-ing');
const btnrec4 = document.getElementById('foodbox4-recipe');
const rexit4 = document.getElementById('rexit4');
const iexit4 = document.getElementById('iexit4');
const ingredients4 = document.getElementById('ingredients4');
const r4ul1 = document.getElementById('r4ul1');
const r4ul2 = document.getElementById('r4ul2');
const r4ul3 = document.getElementById('r4ul3');
const r4ul4 = document.getElementById('r4ul4');
const r4ul5 = document.getElementById('r4ul5');
const r4ul6 = document.getElementById('r4ul6');
const i4ul1 = document.getElementById('i4ul1');
const i4ul2 = document.getElementById('i4ul2');
const i4ul3 = document.getElementById('i4ul3');
const i4ul4 = document.getElementById('i4ul4');
const i4ul5 = document.getElementById('i4ul5');
const i4ul6 = document.getElementById('i4ul6');
// BUTTON 4 END
 
// BUTTON 5 START
const recipe5 = document.getElementById('recipe5');
const btning5 = document.getElementById('foodbox5-ing');
const btnrec5 = document.getElementById('foodbox5-recipe');
const rexit5 = document.getElementById('rexit5');
const iexit5 = document.getElementById('iexit5');
const ingredients5 = document.getElementById('ingredients5');
const r5ul1 = document.getElementById('r5ul1');
const r5ul2 = document.getElementById('r5ul2');
const r5ul3 = document.getElementById('r5ul3');
const r5ul4 = document.getElementById('r5ul4');
const r5ul5 = document.getElementById('r5ul5');
const r5ul6 = document.getElementById('r5ul6');
const i5ul1 = document.getElementById('i5ul1');
const i5ul2 = document.getElementById('i5ul2');
const i5ul3 = document.getElementById('i5ul3');
const i5ul4 = document.getElementById('i5ul4');
const i5ul5 = document.getElementById('i5ul5');
const i5ul6 = document.getElementById('i5ul6');
// BUTTON 5 END

// BUTTON 6 START
const recipe6 = document.getElementById('recipe6');
const btning6 = document.getElementById('foodbox6-ing');
const btnrec6 = document.getElementById('foodbox6-recipe');
const rexit6 = document.getElementById('rexit6');
const iexit6 = document.getElementById('iexit6');
const ingredients6 = document.getElementById('ingredients6');
const r6ul1 = document.getElementById('r6ul1');
const r6ul2 = document.getElementById('r6ul2');
const r6ul3 = document.getElementById('r6ul3');
const r6ul4 = document.getElementById('r6ul4');
const r6ul5 = document.getElementById('r6ul5');
const r6ul6 = document.getElementById('r6ul6');
const i6ul1 = document.getElementById('i6ul1');
const i6ul2 = document.getElementById('i6ul2');
const i6ul3 = document.getElementById('i6ul3');
const i6ul4 = document.getElementById('i6ul4');
const i6ul5 = document.getElementById('i6ul5');
const i6ul6 = document.getElementById('i6ul6');
// BUTTON 6 END

// BUTTON 7 START
const recipe7 = document.getElementById('recipe7');
const btning7 = document.getElementById('foodbox7-ing');
const btnrec7 = document.getElementById('foodbox7-recipe');
const rexit7 = document.getElementById('rexit7');
const iexit7 = document.getElementById('iexit7');
const ingredients7 = document.getElementById('ingredients7');
const r7ul1 = document.getElementById('r7ul1');
const r7ul2 = document.getElementById('r7ul2');
const r7ul3 = document.getElementById('r7ul3');
const r7ul4 = document.getElementById('r7ul4');
const r7ul5 = document.getElementById('r7ul5');
const r7ul6 = document.getElementById('r7ul6');
const i7ul1 = document.getElementById('i7ul1');
const i7ul2 = document.getElementById('i7ul2');
const i7ul3 = document.getElementById('i7ul3');
const i7ul4 = document.getElementById('i7ul4');
const i7ul5 = document.getElementById('i7ul5');
const i7ul6 = document.getElementById('i7ul6');
// BUTTON 7 END

// BUTTON 8 START
const recipe8 = document.getElementById('recipe8');
const btning8 = document.getElementById('foodbox8-ing');
const btnrec8 = document.getElementById('foodbox8-recipe');
const rexit8 = document.getElementById('rexit8');
const iexit8 = document.getElementById('iexit8');
const ingredients8 = document.getElementById('ingredients8');
const r8ul1 = document.getElementById('r8ul1');
const r8ul2 = document.getElementById('r8ul2');
const r8ul3 = document.getElementById('r8ul3');
const r8ul4 = document.getElementById('r8ul4');
const r8ul5 = document.getElementById('r8ul5');
const r8ul6 = document.getElementById('r8ul6');
const i8ul1 = document.getElementById('i8ul1');
const i8ul2 = document.getElementById('i8ul2');
const i8ul3 = document.getElementById('i8ul3');
const i8ul4 = document.getElementById('i8ul4');
const i8ul5 = document.getElementById('i8ul5');
const i8ul6 = document.getElementById('i8ul6');
// BUTTON 8 END


const flag = document.getElementById('flag');
const food1img = document.getElementById('food-box1img');
const h21 = document.getElementById('food-box1h2');
const food2img = document.getElementById('food-box2img');
const h22 = document.getElementById('food-box2h2');
const food3img = document.getElementById('food-box3img');
const h23 = document.getElementById('food-box3h2');
const food4img = document.getElementById('food-box4img');
const h24 = document.getElementById('food-box4h2');
const food5img = document.getElementById('food-box5img');
const h25 = document.getElementById('food-box5h2');
const food6img = document.getElementById('food-box6img');
const h26 = document.getElementById('food-box6h2');
const food7img = document.getElementById('food-box7img');
const h27 = document.getElementById('food-box7h2');
const food8img = document.getElementById('food-box8img');
const h28 = document.getElementById('food-box8h2');


 
flag.addEventListener('change', event => {
    const flags = flag.value;
    switch(flags){
        case 'ph':
            food1img.src = "images/PH/chicken-adobo.png";
            h21.textContent = "Chicken Adobo";
            food2img.src = "images/PH/Kare-Kare.png";
            h22.textContent = "Kare Kare";
            food3img.src = "images/PH/Bicol-Express.png";
            h23.textContent = "Bicol Express";
            food4img.src = "images/PH/Inasal.png";
            h24.textContent = "Inasal";
            food5img.src = "images/PH/Bulalo.png";
            h25.textContent = "Bulalo";
            food6img.src = "images/PH/Humba.png";
            h26.textContent = "Humba";
            food7img.src = "images/PH/Caldereta.png";
            h27.textContent = "Caldereta";
            food8img.src = "images/PH/Sinigang.png";
            h28.textContent = "Sinigang";
            console.log(flags);
            
            // BUTTON 1
        btning1.addEventListener('click', event => {
        ingredients1.style.display = "block";
        h2ingredients1.textContent = "Chicken Adobo";
        ingredients1.animate([
            {transform: 'scale(1)', opacity: 0.5},
            { transform: 'scale(1.1)', opacity: 1 },
            ],{
            duration: 1000,      // Animation duration in milliseconds
             easing: 'ease', // Smooth transition
            fill: "forwards",
            });
    
        
        recipe1.style.display = "none";
        //INGREDIENTS
        i1ul1.textContent = "2 lbs (1 kg) chicken thighs or drumsticks";
        i1ul2.textContent = "1/3 cup soy sauce";
        i1ul3.textContent = "1/3 cup white vinegar";
        i1ul4.textContent = "1/4 cup water";
        i1ul5.textContent = "3 bay leaves";
        i1ul6.textContent = "Salt to taste";
        
    
        }); 

btnrec1.addEventListener('click', event => {
    recipe1.style.display = "block";
    h2recipe1.textContent = "Chicken Adobo";
    ingredients1.style.display = "none";
    recipe1.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    // RECIPE
        r1ul1.textContent = "Marinate the Chicken";
        r1ul2.textContent = "Brown the Chicken";
        r1ul3.textContent = "Add the Marinade";
        r1ul4.textContent = "Simmer and Cook";
        r1ul5.textContent = "Adjust the Sauce";
        r1ul6.textContent = "Serve";
    
});

rexit1.addEventListener('click', event =>{
    recipe1.style.display = "none";
});

iexit1.addEventListener('click', event =>{
    ingredients1.style.display = "none";
});

// BUTTON 1

 // BUTTON START 2
 btning2.addEventListener('click', event => {
    i2ul1.textContent = "This is philippines ingrediets";
    h2ingredients2.textContent = "Kare Kare";
    ingredients2.style.display = "block";
    recipe2.style.display = "none";
    ingredients2.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
    ],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
    });

    i2ul1.textContent = "2 lbs oxtail";
    i2ul2.textContent = "1 banana blossom, sliced";
    i2ul3.textContent = "1 eggplant, sliced";
    i2ul4.textContent = "1/2 cup peanut butter";
    i2ul5.textContent = "Water";

    });

btnrec2.addEventListener('click', event => {
    r2ul2.textContent = "This is philippines reci";
    h2recipe2.textContent = "Kare Kare";
recipe2.style.display = "block";
ingredients2.style.display = "none";
recipe2.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
});

r2ul1.textContent = "Prepare the Meat";
r2ul2.textContent = "Sauté Aromatics";
r2ul3.textContent = "Add Meat";
r2ul4.textContent = "Prepare the Sauce";
r2ul5.textContent = "Cook Vegetables";
r2ul6.textContent = "Serve";

});

rexit2.addEventListener('click', event =>{
recipe2.style.display = "none";
});

iexit2.addEventListener('click', event =>{
ingredients2.style.display = "none";
});
// BUTTON END 2


// BUTTON START 3
btning3.addEventListener('click', event => {
    i3ul1.textContent = "This is philippines ingrediets";
    ingredients3.style.display = "block";
    h2ingredients3.textContent = "Bicol Express";
    recipe3.style.display = "none";
    ingredients3.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
    ],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
    });
    
    i3ul1.textContent = "2 lbs pork belly, cut into cubes";
        i3ul2.textContent = "1 cup coconut milk";
        i3ul3.textContent = "1 cup coconut cream";
        i3ul4.textContent = "6 cloves garlic, minced";
        i3ul5.textContent = "1 onion, chopped";

    });

btnrec3.addEventListener('click', event => {
    r3ul2.textContent = "This is philippines reci";
    h2recipe1.textContent = "Bicol Express";
recipe3.style.display = "block";
ingredients3.style.display = "none";
recipe3.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
});

r3ul1.textContent = "Sauté Aromatics";
r3ul2.textContent = "Cook Pork";
r3ul3.textContent = "Add Chilies and Coconut Cream";
r3ul4.textContent = "Add Shrimp Paste";
r3ul5.textContent = "Add Coconut Milk";
r3ul6.textContent = "Season and Serve";

});

rexit3.addEventListener('click', event =>{
recipe3.style.display = "none";
});

iexit3.addEventListener('click', event =>{
ingredients3.style.display = "none";
});
// BUTTON  END 3



// BUTTON START 4
btning4.addEventListener('click', event => {
    i4ul1.textContent = "This is philippines ingrediets";
    h2ingredients4.textContent = "Inasal";
    ingredients4.style.display = "block";
    recipe4.style.display = "none";
    ingredients4.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
    ],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
    });

    i4ul1.textContent = "2 lbs chicken pieces";
        i4ul2.textContent = "1/2 cup calamansi juice";
        i4ul3.textContent = "1/2 cup coconut vinegar";
        i4ul4.textContent = "6 cloves garlic, minced";
        i4ul5.textContent = "1 head garlic, minced";

    });

btnrec4.addEventListener('click', event => {
    r4ul2.textContent = "This is philippines reci";
    h2recipe1.textContent = "Inasal";
recipe4.style.display = "block";
ingredients4.style.display = "none";
recipe4.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
});

r4ul1.textContent = "Marinate the Chicken";
r4ul2.textContent = "Prepare the Grill";
r4ul3.textContent = "Grill the Chicken";
r4ul4.textContent = "Serve";

});

rexit4.addEventListener('click', event =>{
recipe4.style.display = "none";
});

iexit4.addEventListener('click', event =>{
ingredients4.style.display = "none";
});
// BUTTON  END 4

// BUTTON START 5
btning5.addEventListener('click', event => {
    i5ul1.textContent = "This is philippines ingrediets";
    h2ingredients5.textContent = "Bulalo";
    ingredients5.style.display = "block";
    recipe5.style.display = "none";
    ingredients5.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
    ],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
    });
    i5ul1.textContent = "2 lbs beef shank";
        i5ul2.textContent = "8 cups water";
        i5ul3.textContent = "1 onion, quartered";
        i5ul4.textContent = "2 corn on the cob, cut into pieces";
        i5ul5.textContent = "1 head garlic, crushed";
    });

btnrec5.addEventListener('click', event => {
    r5ul2.textContent = "This is philippines reci";
    h2recipe1.textContent = "Bulalo";
recipe5.style.display = "block";
ingredients5.style.display = "none";
recipe5.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
});

r5ul1.textContent = "Boil the Beef";
r5ul2.textContent = "Simmer";
r5ul3.textContent = "Add Corn and Potatoes";
r5ul4.textContent = "Add Green Vegetables";
r5ul5.textContent = "Serve";

});

rexit5.addEventListener('click', event =>{
recipe5.style.display = "none";
});

iexit5.addEventListener('click', event =>{
ingredients5.style.display = "none";
});
// BUTTON  END 5

// BUTTON START 6
btning6.addEventListener('click', event => {
    i6ul1.textContent = "This is philippines ingrediets";
    h2ingredients6.textContent = "Humba";
    ingredients6.style.display = "block";
    recipe6.style.display = "none";
    ingredients6.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
    ],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
    });

        i6ul1.textContent = "2 lbs pork belly, cut into cubes";
        i6ul2.textContent = "1/2 cup vinegar";
        i6ul3.textContent = "1/2 cup soy sauce";
        i6ul4.textContent = "1/2 cup pineapple juice";
        i6ul5.textContent = "1/4 cup brown sugar";
    });

btnrec6.addEventListener('click', event => {
    r6ul2.textContent = "This is philippines reci";
    h2recipe1.textContent = "Humba";
recipe6.style.display = "block";
ingredients6.style.display = "none";
recipe6.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
});

r6ul1.textContent = "Marinate the Pork";
r6ul2.textContent = "Sauté Aromatics";
r6ul3.textContent = "Brown the Pork";
r6ul4.textContent = "Add Marinade and Spices";
r6ul5.textContent = "Simmer";
r6ul6.textContent = "Adjust Seasoning";

});

rexit6.addEventListener('click', event =>{
recipe6.style.display = "none";
});

iexit6.addEventListener('click', event =>{
ingredients6.style.display = "none";
});
// BUTTON  END 6

// BUTTON START 7
btning7.addEventListener('click', event => {
    i7ul1.textContent = "This is philippines ingrediets";
    h2ingredients7.textContent = "Caldereta";
    ingredients7.style.display = "block";
    recipe7.style.display = "none";
    ingredients7.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
    ],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
    });

    i7ul1.textContent = "2 lbs beef chuck, cut into cubes";
        i7ul2.textContent = "1 cup tomato sauce";
        i7ul3.textContent = "1/2 cup liver spread or pâté";
        i7ul4.textContent = "1 cup beef broth";
        i7ul5.textContent = "1 large potato, cubed";

   
    });

btnrec7.addEventListener('click', event => {
    r7ul2.textContent = "This is philippines reci";
    h2recipe1.textContent = "Caldereta";
recipe7.style.display = "block";
ingredients7.style.display = "none";
recipe7.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
});
r7ul1.textContent = "Sauté Aromatics";
r7ul2.textContent = "Brown the Beef";
r7ul3.textContent = "Add Tomato Sauce and Broth";
r7ul4.textContent = "Simmer";
r7ul5.textContent = "Add Vegetables";
r7ul6.textContent = "Season";
});

rexit7.addEventListener('click', event =>{
recipe7.style.display = "none";
});

iexit7.addEventListener('click', event =>{
ingredients7.style.display = "none";
});
// BUTTON  END 7

// BUTTON START 8
btning8.addEventListener('click', event => {
    i8ul1.textContent = "This is philippines ingrediets";
    h2ingredients8.textContent = "Sinigang";
    ingredients8.style.display = "block";
    recipe8.style.display = "none";
    ingredients8.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
    ],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
    });

        i8ul1.textContent = "2 lbs pork ribs or pork belly, cut into pieces";
        i8ul2.textContent = "8 cups water";
        i8ul3.textContent = "1 onion, quartered";
        i8ul4.textContent = "2 tomatoes, quartered";
        i8ul5.textContent = "1 radish, sliced";

    });

btnrec8.addEventListener('click', event => {
    r8ul2.textContent = "This is philippines reci";
    h2recipe1.textContent = "Sinigang";
recipe8.style.display = "block";
ingredients8.style.display = "none";
recipe8.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
});
r8ul1.textContent = "Boil the Pork";
r8ul2.textContent = "Add Aromatics";
r8ul3.textContent = "Add Vegetables";
r8ul4.textContent = "Season the Soup";
r8ul5.textContent = "Add Greens";
r8ul6.textContent = "Serve";
});

rexit8.addEventListener('click', event =>{
recipe8.style.display = "none";
});

iexit8.addEventListener('click', event =>{
ingredients8.style.display = "none";
});
// BUTTON  END 8



// ---------------------------- JAPAN ---------------------------------------//
            break;
        case 'japan':
            food1img.src = "images/JAPAN/Ramen.png";
            h21.textContent = "Ramen";
            food2img.src = "images/JAPAN/Yakitori.png";
            h22.textContent = "Yakitori";
            food3img.src = "images/JAPAN/Takoyaki.png";
            h23.textContent = "Takoyaki";
            food4img.src = "images/JAPAN/Tamagoyaki.png";
            h24.textContent = "Tamagoyaki";
            food5img.src = "images/PH/chicken-adobo.png";
            h25.textContent = "Okonomiyaki";
            food6img.src = "images/JAPAN/Gyoza.png";
            h26.textContent = "Gyoza";
            food7img.src = "images/JAPAN/Curry Bread.png";
            h27.textContent = "Curry Bread";
            food8img.src = "images/JAPAN/Chawanmushi.png";
            h28.textContent = "Chawanmushi";
            r1ul1.textContent = "This is Japan";
                 // BUTTON 1
        btning1.addEventListener('click', event => {
            ingredients1.style.display = "block";
            h2ingredients1.textContent = "Ramen";
            ingredients1.animate([
                {transform: 'scale(1)', opacity: 0.5},
                { transform: 'scale(1.1)', opacity: 1 },
                ],{
                duration: 1000,      
                 easing: 'ease', 
                fill: "forwards",
                });
        
            
            recipe1.style.display = "none";
            //INGREDIENTS
            i1ul1.textContent = "4 servings of fresh or dried ramen noodles";
            i1ul2.textContent = "4 soft-boiled eggs";
            i1ul3.textContent = "1 cup sliced green onions";
            i1ul4.textContent = "1/4 cup water";
            i1ul5.textContent = "1 cup corn kernels";
            i1ul6.textContent = "1 cup spinach or bok choy";
            
        
            }); 
    
    btnrec1.addEventListener('click', event => {
        recipe1.style.display = "block";
        h2recipe1.textContent = "Ramen";
        ingredients1.style.display = "none";
        recipe1.animate([
            {transform: 'scale(1)', opacity: 0.5},
            { transform: 'scale(1.1)', opacity: 1 },
        ],{
            duration: 1000,      // Animation duration in milliseconds
             easing: 'ease', // Smooth transition
            fill: "forwards",
        });
        // RECIPE
            r1ul1.textContent = "Marinate the Chicken";
            r1ul2.textContent = "Brown the Chicken";
            r1ul3.textContent = "Add the Marinade";
            r1ul4.textContent = "Simmer and Cook";
            r1ul5.textContent = "Adjust the Sauce";
            r1ul6.textContent = "Serve";
        
    });
    
    rexit1.addEventListener('click', event =>{
        recipe1.style.display = "none";
    });
    
    iexit1.addEventListener('click', event =>{
        ingredients1.style.display = "none";
    });
    
    // BUTTON 1
    
     // BUTTON START 2
     btning2.addEventListener('click', event => {
        i2ul1.textContent = "This is philippines ingrediets";
        h2ingredients2.textContent = "Yakitori";
        ingredients2.style.display = "block";
        recipe2.style.display = "none";
        ingredients2.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
        i2ul1.textContent = "2 lbs oxtail";
        i2ul2.textContent = "1 banana blossom, sliced";
        i2ul3.textContent = "1 eggplant, sliced";
        i2ul4.textContent = "1/2 cup peanut butter";
        i2ul5.textContent = "Water";
    
        });
    
    btnrec2.addEventListener('click', event => {
        r2ul2.textContent = "This is philippines reci";
        h2recipe2.textContent = "Yakitori";
    recipe2.style.display = "block";
    ingredients2.style.display = "none";
    recipe2.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r2ul1.textContent = "Prepare the Meat";
    r2ul2.textContent = "Sauté Aromatics";
    r2ul3.textContent = "Add Meat";
    r2ul4.textContent = "Prepare the Sauce";
    r2ul5.textContent = "Cook Vegetables";
    r2ul6.textContent = "Serve";
    
    });
    
    rexit2.addEventListener('click', event =>{
    recipe2.style.display = "none";
    });
    
    iexit2.addEventListener('click', event =>{
    ingredients2.style.display = "none";
    });
    // BUTTON END 2
    
    
    // BUTTON START 3
    btning3.addEventListener('click', event => {
        i3ul1.textContent = "This is philippines ingrediets";
        ingredients3.style.display = "block";
        h2ingredients3.textContent = "Takoyaki";
        recipe3.style.display = "none";
        ingredients3.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
        
        i3ul1.textContent = "2 lbs pork belly, cut into cubes";
            i3ul2.textContent = "1 cup coconut milk";
            i3ul3.textContent = "1 cup coconut cream";
            i3ul4.textContent = "6 cloves garlic, minced";
            i3ul5.textContent = "1 onion, chopped";
    
        });
    
    btnrec3.addEventListener('click', event => {
        r3ul2.textContent = "This is philippines reci";
        h2recipe1.textContent = "Takoyaki";
    recipe3.style.display = "block";
    ingredients3.style.display = "none";
    recipe3.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r3ul1.textContent = "Sauté Aromatics";
    r3ul2.textContent = "Cook Pork";
    r3ul3.textContent = "Add Chilies and Coconut Cream";
    r3ul4.textContent = "Add Shrimp Paste";
    r3ul5.textContent = "Add Coconut Milk";
    r3ul6.textContent = "Season and Serve";
    
    });
    
    rexit3.addEventListener('click', event =>{
    recipe3.style.display = "none";
    });
    
    iexit3.addEventListener('click', event =>{
    ingredients3.style.display = "none";
    });
    // BUTTON  END 3
    
    
    
    // BUTTON START 4
    btning4.addEventListener('click', event => {
        i4ul1.textContent = "This is philippines ingrediets";
        h2ingredients4.textContent = "Tamagoyaki";
        ingredients4.style.display = "block";
        recipe4.style.display = "none";
        ingredients4.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
        i4ul1.textContent = "2 lbs chicken pieces";
            i4ul2.textContent = "1/2 cup calamansi juice";
            i4ul3.textContent = "1/2 cup coconut vinegar";
            i4ul4.textContent = "6 cloves garlic, minced";
            i4ul5.textContent = "1 head garlic, minced";
    
        });
    
    btnrec4.addEventListener('click', event => {
        r4ul2.textContent = "This is philippines reci";
        h2recipe1.textContent = "Tamagoyaki";
    recipe4.style.display = "block";
    ingredients4.style.display = "none";
    recipe4.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r4ul1.textContent = "Marinate the Chicken";
    r4ul2.textContent = "Prepare the Grill";
    r4ul3.textContent = "Grill the Chicken";
    r4ul4.textContent = "Serve";
    
    });
    
    rexit4.addEventListener('click', event =>{
    recipe4.style.display = "none";
    });
    
    iexit4.addEventListener('click', event =>{
    ingredients4.style.display = "none";
    });
    // BUTTON  END 4
    
    // BUTTON START 5
    btning5.addEventListener('click', event => {
        i5ul1.textContent = "This is philippines ingrediets";
        h2ingredients5.textContent = "Okonomiyaki";
        ingredients5.style.display = "block";
        recipe5.style.display = "none";
        ingredients5.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
        i5ul1.textContent = "2 lbs beef shank";
            i5ul2.textContent = "8 cups water";
            i5ul3.textContent = "1 onion, quartered";
            i5ul4.textContent = "2 corn on the cob, cut into pieces";
            i5ul5.textContent = "1 head garlic, crushed";
        });
    
    btnrec5.addEventListener('click', event => {
        r5ul2.textContent = "This is philippines reci";
        h2recipe1.textContent = "Okonomiyaki";
    recipe5.style.display = "block";
    ingredients5.style.display = "none";
    recipe5.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r5ul1.textContent = "Boil the Beef";
    r5ul2.textContent = "Simmer";
    r5ul3.textContent = "Add Corn and Potatoes";
    r5ul4.textContent = "Add Green Vegetables";
    r5ul5.textContent = "Serve";
    
    });
    
    rexit5.addEventListener('click', event =>{
    recipe5.style.display = "none";
    });
    
    iexit5.addEventListener('click', event =>{
    ingredients5.style.display = "none";
    });
    // BUTTON  END 5
    
    // BUTTON START 6
    btning6.addEventListener('click', event => {
        i6ul1.textContent = "This is philippines ingrediets";
        h2ingredients6.textContent = "Humba";
        ingredients6.style.display = "block";
        recipe6.style.display = "none";
        ingredients6.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
            i6ul1.textContent = "2 lbs pork belly, cut into cubes";
            i6ul2.textContent = "1/2 cup vinegar";
            i6ul3.textContent = "1/2 cup soy sauce";
            i6ul4.textContent = "1/2 cup pineapple juice";
            i6ul5.textContent = "1/4 cup brown sugar";
        });
    
    btnrec6.addEventListener('click', event => {
        r6ul2.textContent = "This is philippines reci";
        h2recipe1.textContent = "Humba";
    recipe6.style.display = "block";
    ingredients6.style.display = "none";
    recipe6.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r6ul1.textContent = "Marinate the Pork";
    r6ul2.textContent = "Sauté Aromatics";
    r6ul3.textContent = "Brown the Pork";
    r6ul4.textContent = "Add Marinade and Spices";
    r6ul5.textContent = "Simmer";
    r6ul6.textContent = "Adjust Seasoning";
    
    });
    
    rexit6.addEventListener('click', event =>{
    recipe6.style.display = "none";
    });
    
    iexit6.addEventListener('click', event =>{
    ingredients6.style.display = "none";
    });
    // BUTTON  END 6
    
    // BUTTON START 7
    btning7.addEventListener('click', event => {
        i7ul1.textContent = "This is philippines ingrediets";
        h2ingredients7.textContent = "Caldereta";
        ingredients7.style.display = "block";
        recipe7.style.display = "none";
        ingredients7.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
        i7ul1.textContent = "2 lbs beef chuck, cut into cubes";
            i7ul2.textContent = "1 cup tomato sauce";
            i7ul3.textContent = "1/2 cup liver spread or pâté";
            i7ul4.textContent = "1 cup beef broth";
            i7ul5.textContent = "1 large potato, cubed";
    
       
        });
    
    btnrec7.addEventListener('click', event => {
        r7ul2.textContent = "This is philippines reci";
        h2recipe1.textContent = "Caldereta";
    recipe7.style.display = "block";
    ingredients7.style.display = "none";
    recipe7.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    r7ul1.textContent = "Sauté Aromatics";
    r7ul2.textContent = "Brown the Beef";
    r7ul3.textContent = "Add Tomato Sauce and Broth";
    r7ul4.textContent = "Simmer";
    r7ul5.textContent = "Add Vegetables";
    r7ul6.textContent = "Season";
    });
    
    rexit7.addEventListener('click', event =>{
    recipe7.style.display = "none";
    });
    
    iexit7.addEventListener('click', event =>{
    ingredients7.style.display = "none";
    });
    // BUTTON  END 7
    
    // BUTTON START 8
    btning8.addEventListener('click', event => {
        i8ul1.textContent = "This is philippines ingrediets";
        h2ingredients8.textContent = "Sinigang";
        ingredients8.style.display = "block";
        recipe8.style.display = "none";
        ingredients8.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
            i8ul1.textContent = "2 lbs pork ribs or pork belly, cut into pieces";
            i8ul2.textContent = "8 cups water";
            i8ul3.textContent = "1 onion, quartered";
            i8ul4.textContent = "2 tomatoes, quartered";
            i8ul5.textContent = "1 radish, sliced";
    
        });
    
    btnrec8.addEventListener('click', event => {
        r8ul2.textContent = "This is philippines reci";
        h2recipe1.textContent = "Sinigang";
    recipe8.style.display = "block";
    ingredients8.style.display = "none";
    recipe8.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    r8ul1.textContent = "Boil the Pork";
    r8ul2.textContent = "Add Aromatics";
    r8ul3.textContent = "Add Vegetables";
    r8ul4.textContent = "Season the Soup";
    r8ul5.textContent = "Add Greens";
    r8ul6.textContent = "Serve";
    });
    
    rexit8.addEventListener('click', event =>{
    recipe8.style.display = "none";
    });
    
    iexit8.addEventListener('click', event =>{
    ingredients8.style.display = "none";
    });
    // BUTTON  END 8
    break;
    // ---------------------------- JAPAN ---------------------------------------//
        case 'korea':
    // ---------------------------- KOREA ---------------------------------------//
            food1img.src = "images/KOREA/ Kongguksu.png";
            h21.textContent = "Kongguksu";
            food2img.src = "images/KOREA/odeng.png";
            h22.textContent = "Odeng";
            food3img.src = "images/KOREA/Bibimbap.png";
            h23.textContent = "Bibimbap";
            food4img.src = "images/KOREA/Bulgogi.png";
            h24.textContent = "Bulgogi";
            food5img.src = "images/KOREA/Galbi.png";
            h25.textContent = "Galbi";
            food6img.src = "images/KOREA/Hobakjeon.png";
            h26.textContent = "Hobakjeon";
            food7img.src = "images/KOREA/Japchae.png";
            h27.textContent = "Japchae";
            food8img.src = "images/KOREA/Tteokguk.png";
            h28.textContent = "Tteokguk";
            
            // BUTTON 1
            r1ul1.textContent = "This is Korea";
        btning1.addEventListener('click', event => {
            ingredients1.style.display = "block";
            recipe1.style.display = "none";
            
            ingredients1.animate([
            {transform: 'scale(1)', opacity: 0.5},
            { transform: 'scale(1.1)', opacity: 1 },
            ],{
            duration: 1000,      // Animation duration in milliseconds
             easing: 'ease', // Smooth transition
            fill: "forwards",
            });
    
        
        
            });
    
    btnrec1.addEventListener('click', event => {
        recipe1.style.display = "block";
        ingredients1.style.display = "none";
        recipe1.animate([
            {transform: 'scale(1)', opacity: 0.5},
            { transform: 'scale(1.1)', opacity: 1 },
        ],{
            duration: 1000,      // Animation duration in milliseconds
             easing: 'ease', // Smooth transition
            fill: "forwards",
        });
        
    });
    
    rexit1.addEventListener('click', event =>{
        recipe1.style.display = "none";
    });
    
    iexit1.addEventListener('click', event =>{
        ingredients1.style.display = "none";
    });
    
    // BUTTON 1
            break;
        case 'china':
            food1img.src = "images/CHINA/chow-mein.png";
            h21.textContent = "Chow Mein";
            food2img.src = "images/CHINA/Hot-pot.png";
            h22.textContent = "Hot Pot";
            food3img.src = "images/CHINA/Jianbing.png";
            h23.textContent = "Jianbing";
            food4img.src = "images/CHINA/Kung-Pao.png";
            h24.textContent = "Kung Pao";
            food5img.src = "images/CHINA/Mapo-Tofu.png";
            h25.textContent = "Mapo Tofu";
            food6img.src = "images/CHINA/roasted-duck.png";
            h26.textContent = "Roasted Duck";
            food7img.src = "images/CHINA/sour-pork.png";
            h27.textContent = "Sour Pork";
            food8img.src = "images/CHINA/Xiaolongbao.png";
            h28.textContent = "Xialongbao";

             // BUTTON 1
             r1ul1.textContent = "This is China";
             btning1.addEventListener('click', event => {
                 ingredients1.style.display = "block";
                 recipe1.style.display = "none";
                 
                 ingredients1.animate([
                 {transform: 'scale(1)', opacity: 0.5},
                 { transform: 'scale(1.1)', opacity: 1 },
                 ],{
                 duration: 1000,      // Animation duration in milliseconds
                  easing: 'ease', // Smooth transition
                 fill: "forwards",
                 });
         
             
             
                 });
         
         btnrec1.addEventListener('click', event => {
             recipe1.style.display = "block";
             ingredients1.style.display = "none";
             recipe1.animate([
                 {transform: 'scale(1)', opacity: 0.5},
                 { transform: 'scale(1.1)', opacity: 1 },
             ],{
                 duration: 1000,      // Animation duration in milliseconds
                  easing: 'ease', // Smooth transition
                 fill: "forwards",
             });
             
         });
         
         rexit1.addEventListener('click', event =>{
             recipe1.style.display = "none";
         });
         
         iexit1.addEventListener('click', event =>{
             ingredients1.style.display = "none";
         });
         
         // BUTTON 1
            break;
            case 'italy':
            food1img.src = "images/ITALY/Bruschetta.png";
            h21.textContent = "Bruschetta";
            food2img.src = "images/ITALY/Panzanella.png";
            h22.textContent = "Panzanella";
            food3img.src = "images/ITALY/Pasta-Carbonara.png";
            h23.textContent = "Pasta Carbonara";
            food4img.src = "images/ITALY/pizza-margherita.png";
            h24.textContent = "Pizza Margherita";
            food5img.src = "images/ITALY/Prosciutto.png";
            h25.textContent = "Prosciutto";
            food6img.src = "images/ITALY/risotto.png";
            h26.textContent = "Risotto";
            food7img.src = "images/ITALY/Tiramisu.png";
            h27.textContent = "Tiramisu";
            food8img.src = "images/ITALY/LASAGNA.png";
            h28.textContent = "Lasagna";

            // BUTTON 1
            r1ul1.textContent = "This is Italy";
            btning1.addEventListener('click', event => {
                ingredients1.style.display = "block";
                recipe1.style.display = "none";
                
                ingredients1.animate([
                {transform: 'scale(1)', opacity: 0.5},
                { transform: 'scale(1.1)', opacity: 1 },
                ],{
                duration: 1000,      // Animation duration in milliseconds
                 easing: 'ease', // Smooth transition
                fill: "forwards",
                });
        
            
            
                });
        
        btnrec1.addEventListener('click', event => {
            recipe1.style.display = "block";
            ingredients1.style.display = "none";
            recipe1.animate([
                {transform: 'scale(1)', opacity: 0.5},
                { transform: 'scale(1.1)', opacity: 1 },
            ],{
                duration: 1000,      // Animation duration in milliseconds
                 easing: 'ease', // Smooth transition
                fill: "forwards",
            });
            
        });
        
        rexit1.addEventListener('click', event =>{
            recipe1.style.display = "none";
        });
        
        iexit1.addEventListener('click', event =>{
            ingredients1.style.display = "none";
        });
        
        // BUTTON 1
            break;
    }

});


// // BUTTON 2
// btning1.addEventListener('click', event => {
//     ingredients1.style.display = "block";
//     recipe1.style.display = "none";
//     ingredients1.animate([
//         {transform: 'scale(1)', opacity: 0.5},
//         { transform: 'scale(1.1)', opacity: 1 },
//     ],{
//         duration: 1000,      // Animation duration in milliseconds
//          easing: 'ease', // Smooth transition
//         fill: "forwards",
//     });

    
    
// });

// btnrec1.addEventListener('click', event => {
//     recipe1.style.display = "block";
//     ingredients1.style.display = "none";
//     recipe1.animate([
//         {transform: 'scale(1)', opacity: 0.5},
//         { transform: 'scale(1.1)', opacity: 1 },
//     ],{
//         duration: 1000,      // Animation duration in milliseconds
//          easing: 'ease', // Smooth transition
//         fill: "forwards",
//     });
    
// });

// rexit1.addEventListener('click', event =>{
//     recipe1.style.display = "none";
// });

// iexit1.addEventListener('click', event =>{
//     ingredients1.style.display = "none";
// });

// // BUTTON 2