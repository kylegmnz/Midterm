// foodbox1-ing
// foodbox1-recipe
// BUTTON 1 START
const h2ingredients1 = document.getElementById('h2ingredients1');
const h2ingredients2 = document.getElementById('h2ingredients2');
const h2ingredients3 = document.getElementById('h2ingredients3');
const h2ingredients4 = document.getElementById('h2ingredients4');
const h2ingredients5 = document.getElementById('h2ingredients5');
const h2ingredients6 = document.getElementById('h2ingredients6');
const h2ingredients7 = document.getElementById('h2ingredients7');
const h2ingredients8 = document.getElementById('h2ingredients8');
const h2recipe1 = document.getElementById('h2recipe1');
const h2recipe2 = document.getElementById('h2recipe2');
const h2recipe3 = document.getElementById('h2recipe3');
const h2recipe4 = document.getElementById('h2recipe4');
const h2recipe5 = document.getElementById('h2recipe5');
const h2recipe6 = document.getElementById('h2recipe6');
const h2recipe7 = document.getElementById('h2recipe7');
const h2recipe8 = document.getElementById('h2recipe8');
const recipe1 = document.getElementById('recipe1');
const btning1 = document.getElementById('foodbox1-ing');
const btnrec1 = document.getElementById('foodbox1-recipe');
const rexit1 = document.getElementById('rexit1');
const iexit1 = document.getElementById('iexit1');
const ingredients1 = document.getElementById('ingredients1');
const r1ul1 = document.getElementById('r1ul1');
const r1ul2 = document.getElementById('r1ul2');
const r1ul3 = document.getElementById('r1ul3');
const r1ul4 = document.getElementById('r1ul4');
const r1ul5 = document.getElementById('r1ul5');
const r1ul6 = document.getElementById('r1ul6');
const i1ul1 = document.getElementById('i1ul1');
const i1ul2 = document.getElementById('i1ul2');
const i1ul3 = document.getElementById('i1ul3');
const i1ul4 = document.getElementById('i1ul4');
const i1ul5 = document.getElementById('i1ul5');
const i1ul6 = document.getElementById('i1ul6');

// BUTTON 1 END

// BUTTON 2 START
const recipe2 = document.getElementById('recipe2');
const btning2 = document.getElementById('foodbox2-ing');
const btnrec2 = document.getElementById('foodbox2-recipe');
const rexit2 = document.getElementById('rexit2');
const iexit2 = document.getElementById('iexit2');
const ingredients2 = document.getElementById('ingredients2');
const r2ul1 = document.getElementById('r2ul1');
const r2ul2 = document.getElementById('r2ul2');
const r2ul3 = document.getElementById('r2ul3');
const r2ul4 = document.getElementById('r2ul4');
const r2ul5 = document.getElementById('r2ul5');
const r2ul6 = document.getElementById('r2ul6');
const i2ul1 = document.getElementById('i2ul1');
const i2ul2 = document.getElementById('i2ul2');
const i2ul3 = document.getElementById('i2ul3');
const i2ul4 = document.getElementById('i2ul4');
const i2ul5 = document.getElementById('i2ul5');
const i2ul6 = document.getElementById('i2ul6');

// BUTTON 2 END

// BUTTON 3 STARt
const recipe3 = document.getElementById('recipe3');
const btning3 = document.getElementById('foodbox3-ing');
const btnrec3 = document.getElementById('foodbox3-recipe');
const rexit3 = document.getElementById('rexit3');
const iexit3 = document.getElementById('iexit3');
const ingredients3 = document.getElementById('ingredients3');
const r3ul1 = document.getElementById('r3ul1');
const r3ul2 = document.getElementById('r3ul2');
const r3ul3 = document.getElementById('r3ul3');
const r3ul4 = document.getElementById('r3ul4');
const r3ul5 = document.getElementById('r3ul5');
const r3ul6 = document.getElementById('r3ul6');
const i3ul1 = document.getElementById('i3ul1');
const i3ul2 = document.getElementById('i3ul2');
const i3ul3 = document.getElementById('i3ul3');
const i3ul4 = document.getElementById('i3ul4');
const i3ul5 = document.getElementById('i3ul5');
const i3ul6 = document.getElementById('i3ul6');
// BUTTON 3 END

// BUTTON 4 START
const recipe4 = document.getElementById('recipe4');
const btning4 = document.getElementById('foodbox4-ing');
const btnrec4 = document.getElementById('foodbox4-recipe');
const rexit4 = document.getElementById('rexit4');
const iexit4 = document.getElementById('iexit4');
const ingredients4 = document.getElementById('ingredients4');
const r4ul1 = document.getElementById('r4ul1');
const r4ul2 = document.getElementById('r4ul2');
const r4ul3 = document.getElementById('r4ul3');
const r4ul4 = document.getElementById('r4ul4');
const r4ul5 = document.getElementById('r4ul5');
const r4ul6 = document.getElementById('r4ul6');
const i4ul1 = document.getElementById('i4ul1');
const i4ul2 = document.getElementById('i4ul2');
const i4ul3 = document.getElementById('i4ul3');
const i4ul4 = document.getElementById('i4ul4');
const i4ul5 = document.getElementById('i4ul5');
const i4ul6 = document.getElementById('i4ul6');
// BUTTON 4 END
 
// BUTTON 5 START
const recipe5 = document.getElementById('recipe5');
const btning5 = document.getElementById('foodbox5-ing');
const btnrec5 = document.getElementById('foodbox5-recipe');
const rexit5 = document.getElementById('rexit5');
const iexit5 = document.getElementById('iexit5');
const ingredients5 = document.getElementById('ingredients5');
const r5ul1 = document.getElementById('r5ul1');
const r5ul2 = document.getElementById('r5ul2');
const r5ul3 = document.getElementById('r5ul3');
const r5ul4 = document.getElementById('r5ul4');
const r5ul5 = document.getElementById('r5ul5');
const r5ul6 = document.getElementById('r5ul6');
const i5ul1 = document.getElementById('i5ul1');
const i5ul2 = document.getElementById('i5ul2');
const i5ul3 = document.getElementById('i5ul3');
const i5ul4 = document.getElementById('i5ul4');
const i5ul5 = document.getElementById('i5ul5');
const i5ul6 = document.getElementById('i5ul6');
// BUTTON 5 END

// BUTTON 6 START
const recipe6 = document.getElementById('recipe6');
const btning6 = document.getElementById('foodbox6-ing');
const btnrec6 = document.getElementById('foodbox6-recipe');
const rexit6 = document.getElementById('rexit6');
const iexit6 = document.getElementById('iexit6');
const ingredients6 = document.getElementById('ingredients6');
const r6ul1 = document.getElementById('r6ul1');
const r6ul2 = document.getElementById('r6ul2');
const r6ul3 = document.getElementById('r6ul3');
const r6ul4 = document.getElementById('r6ul4');
const r6ul5 = document.getElementById('r6ul5');
const r6ul6 = document.getElementById('r6ul6');
const i6ul1 = document.getElementById('i6ul1');
const i6ul2 = document.getElementById('i6ul2');
const i6ul3 = document.getElementById('i6ul3');
const i6ul4 = document.getElementById('i6ul4');
const i6ul5 = document.getElementById('i6ul5');
const i6ul6 = document.getElementById('i6ul6');
// BUTTON 6 END

// BUTTON 7 START
const recipe7 = document.getElementById('recipe7');
const btning7 = document.getElementById('foodbox7-ing');
const btnrec7 = document.getElementById('foodbox7-recipe');
const rexit7 = document.getElementById('rexit7');
const iexit7 = document.getElementById('iexit7');
const ingredients7 = document.getElementById('ingredients7');
const r7ul1 = document.getElementById('r7ul1');
const r7ul2 = document.getElementById('r7ul2');
const r7ul3 = document.getElementById('r7ul3');
const r7ul4 = document.getElementById('r7ul4');
const r7ul5 = document.getElementById('r7ul5');
const r7ul6 = document.getElementById('r7ul6');
const i7ul1 = document.getElementById('i7ul1');
const i7ul2 = document.getElementById('i7ul2');
const i7ul3 = document.getElementById('i7ul3');
const i7ul4 = document.getElementById('i7ul4');
const i7ul5 = document.getElementById('i7ul5');
const i7ul6 = document.getElementById('i7ul6');
// BUTTON 7 END

// BUTTON 8 START
const recipe8 = document.getElementById('recipe8');
const btning8 = document.getElementById('foodbox8-ing');
const btnrec8 = document.getElementById('foodbox8-recipe');
const rexit8 = document.getElementById('rexit8');
const iexit8 = document.getElementById('iexit8');
const ingredients8 = document.getElementById('ingredients8');
const r8ul1 = document.getElementById('r8ul1');
const r8ul2 = document.getElementById('r8ul2');
const r8ul3 = document.getElementById('r8ul3');
const r8ul4 = document.getElementById('r8ul4');
const r8ul5 = document.getElementById('r8ul5');
const r8ul6 = document.getElementById('r8ul6');
const i8ul1 = document.getElementById('i8ul1');
const i8ul2 = document.getElementById('i8ul2');
const i8ul3 = document.getElementById('i8ul3');
const i8ul4 = document.getElementById('i8ul4');
const i8ul5 = document.getElementById('i8ul5');
const i8ul6 = document.getElementById('i8ul6');
// BUTTON 8 END


const flag = document.getElementById('flag');
const food1img = document.getElementById('food-box1img');
const h21 = document.getElementById('food-box1h2');
const food2img = document.getElementById('food-box2img');
const h22 = document.getElementById('food-box2h2');
const food3img = document.getElementById('food-box3img');
const h23 = document.getElementById('food-box3h2');
const food4img = document.getElementById('food-box4img');
const h24 = document.getElementById('food-box4h2');
const food5img = document.getElementById('food-box5img');
const h25 = document.getElementById('food-box5h2');
const food6img = document.getElementById('food-box6img');
const h26 = document.getElementById('food-box6h2');
const food7img = document.getElementById('food-box7img');
const h27 = document.getElementById('food-box7h2');
const food8img = document.getElementById('food-box8img');
const h28 = document.getElementById('food-box8h2');


 
flag.addEventListener('change', event => {
    const flags = flag.value;
    switch(flags){
        case 'ph':
            food1img.src = "images/PH/chicken-adobo.png";
            h21.textContent = "Chicken Adobo";
            food2img.src = "images/PH/Kare-Kare.png";
            h22.textContent = "Kare Kare";
            food3img.src = "images/PH/Bicol-Express.png";
            h23.textContent = "Bicol Express";
            food4img.src = "images/PH/Inasal.png";
            h24.textContent = "Inasal";
            food5img.src = "images/PH/Bulalo.png";
            h25.textContent = "Bulalo";
            food6img.src = "images/PH/Humba.png";
            h26.textContent = "Humba";
            food7img.src = "images/PH/Caldereta.png";
            h27.textContent = "Caldereta";
            food8img.src = "images/PH/Sinigang.png";
            h28.textContent = "Sinigang";
            console.log(flags);
            
            // BUTTON 1
        btning1.addEventListener('click', event => {
        ingredients1.style.display = "block";
        h2ingredients1.textContent = "Chicken Adobo";
        ingredients1.animate([
            {transform: 'scale(1)', opacity: 0.5},
            { transform: 'scale(1.1)', opacity: 1 },
            ],{
            duration: 1000,      // Animation duration in milliseconds
             easing: 'ease', // Smooth transition
            fill: "forwards",
            });
    
        
        recipe1.style.display = "none";
        //INGREDIENTS
        i1ul1.textContent = "2 lbs (1 kg) chicken thighs or drumsticks";
        i1ul2.textContent = "1/3 cup soy sauce";
        i1ul3.textContent = "1/3 cup white vinegar";
        i1ul4.textContent = "1/4 cup water";
        i1ul5.textContent = "3 bay leaves";
        i1ul6.textContent = "Salt to taste";
        
    
        }); 

btnrec1.addEventListener('click', event => {
    recipe1.style.display = "block";
    h2recipe1.textContent = "Chicken Adobo";
    ingredients1.style.display = "none";
    recipe1.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    // RECIPE
        r1ul1.textContent = "Marinate the Chicken";
        r1ul2.textContent = "Brown the Chicken";
        r1ul3.textContent = "Add the Marinade";
        r1ul4.textContent = "Simmer and Cook";
        r1ul5.textContent = "Adjust the Sauce";
        r1ul6.textContent = "Serve";
    
});

rexit1.addEventListener('click', event =>{
    recipe1.style.display = "none";
});

iexit1.addEventListener('click', event =>{
    ingredients1.style.display = "none";
});

// BUTTON 1

 // BUTTON START 2
 btning2.addEventListener('click', event => {
    i2ul1.textContent = "This is philippines ingrediets";
    h2ingredients2.textContent = "Kare Kare";
    ingredients2.style.display = "block";
    recipe2.style.display = "none";
    ingredients2.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
    ],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
    });

    i2ul1.textContent = "2 lbs oxtail";
    i2ul2.textContent = "1 banana blossom, sliced";
    i2ul3.textContent = "1 eggplant, sliced";
    i2ul4.textContent = "1/2 cup peanut butter";
    i2ul5.textContent = "Water";

    });

btnrec2.addEventListener('click', event => {
    r2ul2.textContent = "This is philippines reci";
    h2recipe2.textContent = "Kare Kare";
recipe2.style.display = "block";
ingredients2.style.display = "none";
recipe2.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
});

r2ul1.textContent = "Prepare the Meat";
r2ul2.textContent = "Sauté Aromatics";
r2ul3.textContent = "Add Meat";
r2ul4.textContent = "Prepare the Sauce";
r2ul5.textContent = "Cook Vegetables";
r2ul6.textContent = "Serve";

});

rexit2.addEventListener('click', event =>{
recipe2.style.display = "none";
});

iexit2.addEventListener('click', event =>{
ingredients2.style.display = "none";
});
// BUTTON END 2


// BUTTON START 3
btning3.addEventListener('click', event => {
    i3ul1.textContent = "This is philippines ingrediets";
    ingredients3.style.display = "block";
    h2ingredients3.textContent = "Bicol Express";
    recipe3.style.display = "none";
    ingredients3.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
    ],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
    });
    
    i3ul1.textContent = "2 lbs pork belly, cut into cubes";
        i3ul2.textContent = "1 cup coconut milk";
        i3ul3.textContent = "1 cup coconut cream";
        i3ul4.textContent = "6 cloves garlic, minced";
        i3ul5.textContent = "1 onion, chopped";

    });

btnrec3.addEventListener('click', event => {
    r3ul2.textContent = "This is philippines reci";
    h2recipe3.textContent = "Bicol Express";
recipe3.style.display = "block";
ingredients3.style.display = "none";
recipe3.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
});

r3ul1.textContent = "Sauté Aromatics";
r3ul2.textContent = "Cook Pork";
r3ul3.textContent = "Add Chilies and Coconut Cream";
r3ul4.textContent = "Add Shrimp Paste";
r3ul5.textContent = "Add Coconut Milk";
r3ul6.textContent = "Season and Serve";

});

rexit3.addEventListener('click', event =>{
recipe3.style.display = "none";
});

iexit3.addEventListener('click', event =>{
ingredients3.style.display = "none";
});
// BUTTON  END 3



// BUTTON START 4
btning4.addEventListener('click', event => {
    i4ul1.textContent = "This is philippines ingrediets";
    h2ingredients4.textContent = "Inasal";
    ingredients4.style.display = "block";
    recipe4.style.display = "none";
    ingredients4.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
    ],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
    });

    i4ul1.textContent = "2 lbs chicken pieces";
        i4ul2.textContent = "1/2 cup calamansi juice";
        i4ul3.textContent = "1/2 cup coconut vinegar";
        i4ul4.textContent = "6 cloves garlic, minced";
        i4ul5.textContent = "1 head garlic, minced";

    });

btnrec4.addEventListener('click', event => {
    r4ul2.textContent = "This is philippines reci";
    h2recipe4.textContent = "Inasal";
recipe4.style.display = "block";
ingredients4.style.display = "none";
recipe4.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
});

r4ul1.textContent = "Marinate the Chicken";
r4ul2.textContent = "Prepare the Grill";
r4ul3.textContent = "Grill the Chicken";
r4ul4.textContent = "Serve";

});

rexit4.addEventListener('click', event =>{
recipe4.style.display = "none";
});

iexit4.addEventListener('click', event =>{
ingredients4.style.display = "none";
});
// BUTTON  END 4

// BUTTON START 5
btning5.addEventListener('click', event => {
    i5ul1.textContent = "This is philippines ingrediets";
    h2ingredients5.textContent = "Bulalo";
    ingredients5.style.display = "block";
    recipe5.style.display = "none";
    ingredients5.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
    ],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
    });
    i5ul1.textContent = "2 lbs beef shank";
        i5ul2.textContent = "8 cups water";
        i5ul3.textContent = "1 onion, quartered";
        i5ul4.textContent = "2 corn on the cob, cut into pieces";
        i5ul5.textContent = "1 head garlic, crushed";
    });

btnrec5.addEventListener('click', event => {
    r5ul2.textContent = "This is philippines reci";
    h2recipe5.textContent = "Bulalo";
recipe5.style.display = "block";
ingredients5.style.display = "none";
recipe5.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
});

r5ul1.textContent = "Boil the Beef";
r5ul2.textContent = "Simmer";
r5ul3.textContent = "Add Corn and Potatoes";
r5ul4.textContent = "Add Green Vegetables";
r5ul5.textContent = "Serve";

});

rexit5.addEventListener('click', event =>{
recipe5.style.display = "none";
});

iexit5.addEventListener('click', event =>{
ingredients5.style.display = "none";
});
// BUTTON  END 5

// BUTTON START 6
btning6.addEventListener('click', event => {
    i6ul1.textContent = "This is philippines ingrediets";
    h2ingredients6.textContent = "Humba";
    ingredients6.style.display = "block";
    recipe6.style.display = "none";
    ingredients6.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
    ],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
    });

        i6ul1.textContent = "2 lbs pork belly, cut into cubes";
        i6ul2.textContent = "1/2 cup vinegar";
        i6ul3.textContent = "1/2 cup soy sauce";
        i6ul4.textContent = "1/2 cup pineapple juice";
        i6ul5.textContent = "1/4 cup brown sugar";
    });

btnrec6.addEventListener('click', event => {
    r6ul2.textContent = "This is philippines reci";
    h2recipe6.textContent = "Humba";
recipe6.style.display = "block";
ingredients6.style.display = "none";
recipe6.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
});

r6ul1.textContent = "Marinate the Pork";
r6ul2.textContent = "Sauté Aromatics";
r6ul3.textContent = "Brown the Pork";
r6ul4.textContent = "Add Marinade and Spices";
r6ul5.textContent = "Simmer";
r6ul6.textContent = "Adjust Seasoning";

});

rexit6.addEventListener('click', event =>{
recipe6.style.display = "none";
});

iexit6.addEventListener('click', event =>{
ingredients6.style.display = "none";
});
// BUTTON  END 6

// BUTTON START 7
btning7.addEventListener('click', event => {
    i7ul1.textContent = "This is philippines ingrediets";
    h2ingredients7.textContent = "Caldereta";
    ingredients7.style.display = "block";
    recipe7.style.display = "none";
    ingredients7.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
    ],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
    });

    i7ul1.textContent = "2 lbs beef chuck, cut into cubes";
        i7ul2.textContent = "1 cup tomato sauce";
        i7ul3.textContent = "1/2 cup liver spread or pâté";
        i7ul4.textContent = "1 cup beef broth";
        i7ul5.textContent = "1 large potato, cubed";

   
    });

btnrec7.addEventListener('click', event => {
    r7ul2.textContent = "This is philippines reci";
    h2recipe7.textContent = "Caldereta";
recipe7.style.display = "block";
ingredients7.style.display = "none";
recipe7.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
});
r7ul1.textContent = "Sauté Aromatics";
r7ul2.textContent = "Brown the Beef";
r7ul3.textContent = "Add Tomato Sauce and Broth";
r7ul4.textContent = "Simmer";
r7ul5.textContent = "Add Vegetables";
r7ul6.textContent = "Season";
});

rexit7.addEventListener('click', event =>{
recipe7.style.display = "none";
});

iexit7.addEventListener('click', event =>{
ingredients7.style.display = "none";
});
// BUTTON  END 7

// BUTTON START 8
btning8.addEventListener('click', event => {
    i8ul1.textContent = "This is philippines ingrediets";
    h2ingredients8.textContent = "Sinigang";
    ingredients8.style.display = "block";
    recipe8.style.display = "none";
    ingredients8.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
    ],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
    });

        i8ul1.textContent = "2 lbs pork ribs or pork belly, cut into pieces";
        i8ul2.textContent = "8 cups water";
        i8ul3.textContent = "1 onion, quartered";
        i8ul4.textContent = "2 tomatoes, quartered";
        i8ul5.textContent = "1 radish, sliced";

    });

btnrec8.addEventListener('click', event => {
    r8ul2.textContent = "This is philippines reci";
    h2recipe8.textContent = "Sinigang";
recipe8.style.display = "block";
ingredients8.style.display = "none";
recipe8.animate([
    {transform: 'scale(1)', opacity: 0.5},
    { transform: 'scale(1.1)', opacity: 1 },
],{
    duration: 1000,      // Animation duration in milliseconds
     easing: 'ease', // Smooth transition
    fill: "forwards",
});
r8ul1.textContent = "Boil the Pork";
r8ul2.textContent = "Add Aromatics";
r8ul3.textContent = "Add Vegetables";
r8ul4.textContent = "Season the Soup";
r8ul5.textContent = "Add Greens";
r8ul6.textContent = "Serve";
});

rexit8.addEventListener('click', event =>{
recipe8.style.display = "none";
});

iexit8.addEventListener('click', event =>{
ingredients8.style.display = "none";
});
// BUTTON  END 8



// ---------------------------- JAPAN ---------------------------------------//
            break;
        case 'japan':
            food1img.src = "images/JAPAN/Ramen.png";
            h21.textContent = "Ramen";
            food2img.src = "images/JAPAN/Yakitori.png";
            h22.textContent = "Yakitori";
            food3img.src = "images/JAPAN/Takoyaki.png";
            h23.textContent = "Takoyaki";
            food4img.src = "images/JAPAN/Tamagoyaki.png";
            h24.textContent = "Tamagoyaki";
            food5img.src = "images/PH/chicken-adobo.png";
            h25.textContent = "Okonomiyaki";
            food6img.src = "images/JAPAN/Gyoza.png";
            h26.textContent = "Gyoza";
            food7img.src = "images/JAPAN/Curry Bread.png";
            h27.textContent = "Curry Bread";
            food8img.src = "images/JAPAN/Chawanmushi.png";
            h28.textContent = "Chawanmushi";
            r1ul1.textContent = "This is Japan";
                 // BUTTON 1
        btning1.addEventListener('click', event => {
            ingredients1.style.display = "block";
            h2ingredients1.textContent = "Ramen Ingredients";
            ingredients1.animate([
                {transform: 'scale(1)', opacity: 0.5},
                { transform: 'scale(1.1)', opacity: 1 },
                ],{
                duration: 1000,      
                 easing: 'ease', 
                fill: "forwards",
                });
        
            
            recipe1.style.display = "none";
            //INGREDIENTS
            i1ul1.textContent = "4 servings of fresh or dried ramen noodles";
            i1ul2.textContent = "4 soft-boiled eggs";
            i1ul3.textContent = "1 cup sliced green onions";
            i1ul4.textContent = "1/4 cup water";
            i1ul5.textContent = "1 cup corn kernels";
            i1ul6.textContent = "1 cup spinach or bok choy";
            
        
            }); 
    
    btnrec1.addEventListener('click', event => {
        recipe1.style.display = "block";
        h2recipe1.textContent = "Ramen Recipe";
        ingredients1.style.display = "none";
        recipe1.animate([
            {transform: 'scale(1)', opacity: 0.5},
            { transform: 'scale(1.1)', opacity: 1 },
        ],{
            duration: 1000,      // Animation duration in milliseconds
             easing: 'ease', // Smooth transition
            fill: "forwards",
        });
        // RECIPE
            r1ul1.textContent = "Prepare the Broth";
            r1ul2.textContent = "Cook the Noodles";
            r1ul3.textContent = "Prepare the Toppings";
            r1ul4.textContent = "Assemble the Ramen";
            r1ul6.textContent = "Serve";
        
    });
    
    rexit1.addEventListener('click', event =>{
        recipe1.style.display = "none";
    });
    
    iexit1.addEventListener('click', event =>{
        ingredients1.style.display = "none";
    });
    
    // BUTTON 1
    
     // BUTTON START 2
     btning2.addEventListener('click', event => {
        i2ul1.textContent = "This is philippines ingrediets";
        h2ingredients2.textContent = "Yakitori Ingredients";
        ingredients2.style.display = "block";
        recipe2.style.display = "none";
        ingredients2.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
        i2ul1.textContent = "1 lb chicken thighs, cut into bite-sized pieces";
        i2ul2.textContent = "1/2 cup soy sauce";
        i2ul3.textContent = "1/4 cup mirin (sweet rice wine)";
        i2ul4.textContent = "1/4 cup sake (Japanese rice wine)";
        i2ul5.textContent = "2 tablespoons sugar";
    
        });
    
    btnrec2.addEventListener('click', event => {
        r2ul2.textContent = "This is philippines reci";
        h2recipe2.textContent = "Yakitori Recipe";
    recipe2.style.display = "block";
    ingredients2.style.display = "none";
    recipe2.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r2ul1.textContent = "Prepare the Marinade";
    r2ul2.textContent = "Skewer the Chicken";
    r2ul3.textContent = "Marinate the Skewers";
    r2ul4.textContent = "Grill the Yakitori";
    r2ul6.textContent = "Serve";
    
    });
    
    rexit2.addEventListener('click', event =>{
    recipe2.style.display = "none";
    });
    
    iexit2.addEventListener('click', event =>{
    ingredients2.style.display = "none";
    });
    // BUTTON END 2
    
    
    // BUTTON START 3
    btning3.addEventListener('click', event => {
        i3ul1.textContent = "This is philippines ingrediets";
        ingredients3.style.display = "block";
        h2ingredients3.textContent = "Takoyaki Ingredients";
        recipe3.style.display = "none";
        ingredients3.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
        
        i3ul1.textContent = "2 large eggs";
            i3ul2.textContent = "1 cup all-purpose flour";
            i3ul3.textContent = "2 cups dashi (Japanese soup stock)";
            i3ul4.textContent = "1/2 teaspoon soy sauce";
            i3ul5.textContent = "1/2 teaspoon baking powder";
    
        });
    
    btnrec3.addEventListener('click', event => {
        r3ul2.textContent = "This is philippines reci";
        h2recipe3.textContent = "Takoyaki Recipe";
    recipe3.style.display = "block";
    ingredients3.style.display = "none";
    recipe3.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r3ul1.textContent = "Prepare the Batter";
    r3ul2.textContent = "Heat the Takoyaki Pan";
    r3ul3.textContent = "Cook the Takoyaki";
    r3ul4.textContent = "Turn the Takoyaki";
    r3ul5.textContent = "Serve";
    
    });
    
    rexit3.addEventListener('click', event =>{
    recipe3.style.display = "none";
    });
    
    iexit3.addEventListener('click', event =>{
    ingredients3.style.display = "none";
    });
    // BUTTON  END 3
    
    
    
    // BUTTON START 4
    btning4.addEventListener('click', event => {
        i4ul1.textContent = "This is philippines ingrediets";
        h2ingredients4.textContent = "Tamagoyaki Ingredients";
        ingredients4.style.display = "block";
        recipe4.style.display = "none";
        ingredients4.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
        i4ul1.textContent = "4 large eggs";
            i4ul2.textContent = "2 tablespoons dashi (Japanese soup stock)";
            i4ul3.textContent = "1 tablespoon soy sauce";
            i4ul4.textContent = "1 tablespoon mirin (sweet rice wine)";
            i4ul5.textContent = "Cooking oil";
    
        });
    
    btnrec4.addEventListener('click', event => {
        r4ul2.textContent = "This is philippines reci";
        h2recipe4.textContent = "Tamagoyaki Recipe";
    recipe4.style.display = "block";
    ingredients4.style.display = "none";
    recipe4.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r4ul1.textContent = "Prepare the Egg Mixture";
    r4ul2.textContent = "Heat the Pan";
    r4ul3.textContent = "Cook the Omelette";
    r4ul4.textContent = "Roll the Omelette";
    r4ul5.textContent = "Add More Egg Mixture";
    r4ul6.textContent = "Shape and Serve";
    
    });
    
    rexit4.addEventListener('click', event =>{
    recipe4.style.display = "none";
    });
    
    iexit4.addEventListener('click', event =>{
    ingredients4.style.display = "none";
    });
    // BUTTON  END 4
    
    // BUTTON START 5
    btning5.addEventListener('click', event => {
        i5ul1.textContent = "This is philippines ingrediets";
        h2ingredients5.textContent = "Okonomiyaki Ingredients";
        ingredients5.style.display = "block";
        recipe5.style.display = "none";
        ingredients5.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
        i5ul1.textContent = "1 cup all-purpose flour";
            i5ul2.textContent = "2/3 cup dashi (Japanese soup stock) or water";
            i5ul3.textContent = "2 large eggs";
            i5ul4.textContent = "1/4 cup grated yam or potato (optional, for extra fluffiness)";
        });
    
    btnrec5.addEventListener('click', event => {
        r5ul2.textContent = "This is philippines reci";
        h2recipe5.textContent = "Okonomiyaki Recipe";
    recipe5.style.display = "block";
    ingredients5.style.display = "none";
    recipe5.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r5ul1.textContent = "Prepare the Batter";
    r5ul2.textContent = "Add Fillings";
    r5ul3.textContent = "Cook the Okonomiyaki";
    r5ul4.textContent = "Flip and Cook";
    r5ul5.textContent = "Add Toppings";
    
    });
    
    rexit5.addEventListener('click', event =>{
    recipe5.style.display = "none";
    });
    
    iexit5.addEventListener('click', event =>{
    ingredients5.style.display = "none";
    });
    // BUTTON  END 5
    
    // BUTTON START 6
    btning6.addEventListener('click', event => {
        i6ul1.textContent = "This is philippines ingrediets";
        h2ingredients6.textContent = "Gyoza Ingredients";
        ingredients6.style.display = "block";
        recipe6.style.display = "none";
        ingredients6.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
            i6ul1.textContent = "1/2 lb ground pork";
            i6ul2.textContent = "1 cup cabbage, finely chopped";
            i6ul3.textContent = "1/4 cup green onions, finely chopped";
            i6ul4.textContent = "2 cloves garlic, minced";
            i6ul5.textContent = "1 tablespoon ginger, grated";
        });
    
    btnrec6.addEventListener('click', event => {
        r6ul2.textContent = "This is philippines reci";
        h2recipe6.textContent = "Gyoza Recipe";
    recipe6.style.display = "block";
    ingredients6.style.display = "none";
    recipe6.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r6ul1.textContent = "Prepare the Filling";
    r6ul2.textContent = "Assemble the Gyoza";
    r6ul3.textContent = "Cook the Gyoza";
    r6ul4.textContent = "Add Marinade and Spices";
    r6ul5.textContent = "Serve";
    
    });
    
    rexit6.addEventListener('click', event =>{
    recipe6.style.display = "none";
    });
    
    iexit6.addEventListener('click', event =>{
    ingredients6.style.display = "none";
    });
    // BUTTON  END 6
    
    // BUTTON START 7
    btning7.addEventListener('click', event => {
        i7ul1.textContent = "This is philippines ingrediets";
        h2ingredients7.textContent = "Curry Bread Ingredients";
        ingredients7.style.display = "block";
        recipe7.style.display = "none";
        ingredients7.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
        i7ul1.textContent = "2 cups all-purpose flour";
            i7ul2.textContent = "1/2 cup warm milk";
            i7ul3.textContent = "1/4 cup warm water";
            i7ul4.textContent = "2 tablespoons sugar";
            i7ul5.textContent = "1 teaspoon salt";
    
       
        });
    
    btnrec7.addEventListener('click', event => {
        r7ul2.textContent = "This is philippines reci";
        h2recipe7.textContent = "Curry Bread Recipe";
    recipe7.style.display = "block";
    ingredients7.style.display = "none";
    recipe7.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    r7ul1.textContent = "Prepare the Dough";
    r7ul2.textContent = "Prepare the Curry Filling";
    r7ul3.textContent = "Add Tomato Sauce and Broth";
    r7ul4.textContent = "Coat the Bread";
    r7ul5.textContent = "Fry the Bread";
    r7ul6.textContent = "Serve";
    });
    
    rexit7.addEventListener('click', event =>{
    recipe7.style.display = "none";
    });
    
    iexit7.addEventListener('click', event =>{
    ingredients7.style.display = "none";
    });
    // BUTTON  END 7
    
    // BUTTON START 8
    btning8.addEventListener('click', event => {
        i8ul1.textContent = "This is philippines ingrediets";
        h2ingredients8.textContent = "Chawanmushi Ingredients";
        ingredients8.style.display = "block";
        recipe8.style.display = "none";
        ingredients8.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
            i8ul1.textContent = "4 large eggs";
            i8ul2.textContent = "2 cups dashi (Japanese soup stock)";
            i8ul3.textContent = "1 tablespoon soy sauce";
            i8ul4.textContent = "1 tablespoon mirin (sweet rice wine)";
            i8ul5.textContent = "1/2 teaspoon salt";
    
        });
    
    btnrec8.addEventListener('click', event => {
        r8ul2.textContent = "This is philippines reci";
        h2recipe8.textContent = "Chawanmushi Recipe";
    recipe8.style.display = "block";
    ingredients8.style.display = "none";
    recipe8.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    r8ul1.textContent = "Boil the Pork";
    r8ul2.textContent = "Prepare the Cups";
    r8ul3.textContent = "Pour the Egg Mixture";
    r8ul4.textContent = "Steam the Custard";
    r8ul5.textContent = "Garnish and Serve";
    });
    
    rexit8.addEventListener('click', event =>{
    recipe8.style.display = "none";
    });
    
    iexit8.addEventListener('click', event =>{
    ingredients8.style.display = "none";
    });
    // BUTTON  END 8
    break;
    // ---------------------------- JAPAN ---------------------------------------//
        case 'korea':
    // ---------------------------- KOREA ---------------------------------------//
            food1img.src = "images/KOREA/ Kongguksu.png";
            h21.textContent = "Kongguksu";
            food2img.src = "images/KOREA/odeng.png";
            h22.textContent = "Odeng";
            food3img.src = "images/KOREA/Bibimbap.png";
            h23.textContent = "Bibimbap";
            food4img.src = "images/KOREA/Bulgogi.png";
            h24.textContent = "Bulgogi";
            food5img.src = "images/KOREA/Galbi.png";
            h25.textContent = "Galbi";
            food6img.src = "images/KOREA/Hobakjeon.png";
            h26.textContent = "Hobakjeon";
            food7img.src = "images/KOREA/Japchae.png";
            h27.textContent = "Japchae";
            food8img.src = "images/KOREA/Tteokguk.png";
            h28.textContent = "Tteokguk";
            
               // BUTTON 1
        btning1.addEventListener('click', event => {
            ingredients1.style.display = "block";
            h2ingredients1.textContent = "Kongguksu Ingredients";
            ingredients1.animate([
                {transform: 'scale(1)', opacity: 0.5},
                { transform: 'scale(1.1)', opacity: 1 },
                ],{
                duration: 1000,      
                 easing: 'ease', 
                fill: "forwards",
                });
        
            
            recipe1.style.display = "none";
            //INGREDIENTS
            i1ul1.textContent = "Prepare the soybeans";
            i1ul2.textContent = "Make the soy milk";
            i1ul3.textContent = "Cook the noodles";
            i1ul4.textContent = "Season the soy milk";
            i1ul5.textContent = "Assemble the dish";
            i1ul6.textContent = "Add toppings";
            
        
            }); 
    
    btnrec1.addEventListener('click', event => {
        recipe1.style.display = "block";
        h2recipe1.textContent = "Kongguksu Recipe";
        ingredients1.style.display = "none";
        recipe1.animate([
            {transform: 'scale(1)', opacity: 0.5},
            { transform: 'scale(1.1)', opacity: 1 },
        ],{
            duration: 1000,      // Animation duration in milliseconds
             easing: 'ease', // Smooth transition
            fill: "forwards",
        });
        // RECIPE
            r1ul1.textContent = "1 cup dried soybeans";
            r1ul2.textContent = "2 servings of thin wheat noodles";
            r1ul3.textContent = "1/2 teaspoon salt";
            r1ul4.textContent = "1/2 cucumber (sliced)";
            r1ul5.textContent = "1 boiled egg (halved)";
            r1ul6.textContent = "1 small tomato(sliced)";
        
    });
    
    rexit1.addEventListener('click', event =>{
        recipe1.style.display = "none";
    });
    
    iexit1.addEventListener('click', event =>{
        ingredients1.style.display = "none";
    });
    
    // BUTTON 1
    
     // BUTTON START 2
     btning2.addEventListener('click', event => {
        i2ul1.textContent = "This is philippines ingrediets";
        h2ingredients2.textContent = "Odeng Ingredients";
        ingredients2.style.display = "block";
        recipe2.style.display = "none";
        ingredients2.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
        i2ul1.textContent = "4-5 fish cakes";
        i2ul2.textContent = "1.5 liters water";
        i2ul3.textContent = "6 dried anchovies";
        i2ul4.textContent = "1 sheet of dried kelp";
        i2ul5.textContent = "1/2 onion, sliced";
        i2ul6.textContent = "2 cloves garlic, crushed";
    
        });
    
    btnrec2.addEventListener('click', event => {
        r2ul2.textContent = "This is philippines reci";
        h2recipe2.textContent = "Odeng Recipe";
    recipe2.style.display = "block";
    ingredients2.style.display = "none";
    recipe2.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r2ul1.textContent = "Prepare the Broth";
    r2ul2.textContent = "Season the Broth";
    r2ul3.textContent = "Prepare the Fish Cakes";
    r2ul4.textContent = "Cook the Skewers";
    r2ul5.textContent = "Serve";
    
    });
    
    rexit2.addEventListener('click', event =>{
    recipe2.style.display = "none";
    });
    
    iexit2.addEventListener('click', event =>{
    ingredients2.style.display = "none";
    });
    // BUTTON END 2
    
    
    // BUTTON START 3
    btning3.addEventListener('click', event => {
        i3ul1.textContent = "This is philippines ingrediets";
        ingredients3.style.display = "block";
        h2ingredients3.textContent = "Bibimbap Ingredients";
        recipe3.style.display = "none";
        ingredients3.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
        
        i3ul1.textContent = "2 cups steamed white rice";
            i3ul2.textContent = "1 cup spinach";
            i3ul3.textContent = "1 carrot";
            i3ul4.textContent = "1 zucchini";
            i3ul5.textContent = "4-5 shiitake mushrooms";
            i3ul6.textContent = "Bean sprouts";
    
        });
    
    btnrec3.addEventListener('click', event => {
        r3ul2.textContent = "This is philippines reci";
        h2recipe3.textContent = "Bibimbap Recipe";
    recipe3.style.display = "block";
    ingredients3.style.display = "none";
    recipe3.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r3ul1.textContent = "Cook the Rice";
    r3ul2.textContent = "Prepare the Vegetables";
    r3ul3.textContent = "Prepare the Protein";
    r3ul4.textContent = "Prepare the Sauce";
    r3ul5.textContent = "Assemble the Bibimbap";
    r3ul6.textContent = "Serve";
    
    });
    
    rexit3.addEventListener('click', event =>{
    recipe3.style.display = "none";
    });
    
    iexit3.addEventListener('click', event =>{
    ingredients3.style.display = "none";
    });
    // BUTTON  END 3
    
    
    
    // BUTTON START 4
    btning4.addEventListener('click', event => {
        i4ul1.textContent = "This is philippines ingrediets";
        h2ingredients4.textContent = "Bulgogi Ingredients";
        ingredients4.style.display = "block";
        recipe4.style.display = "none";
        ingredients4.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
        i4ul1.textContent = "1 lb beef ribeye or sirloin";
            i4ul2.textContent = "3 tbsp soy sauce";
            i4ul3.textContent = "1 tbsp sesame oil";
            i4ul4.textContent = "1 tbsp sugar ";
            i4ul5.textContent = "1 tbsp mirin";
            i4ul6.textContent = "2 green onions";
    
        });
    
    btnrec4.addEventListener('click', event => {
        r4ul2.textContent = "This is philippines reci";
        h2recipe4.textContent = "Bulgogi Recipe";
    recipe4.style.display = "block";
    ingredients4.style.display = "none";
    recipe4.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r4ul1.textContent = "Prepare the Beef";
    r4ul2.textContent = "Make the Marinade";
    r4ul3.textContent = "Marinate the Meat";
    r4ul4.textContent = "Cook the Bulgogi";
    r4ul5.textContent = "Serve";
    
    
    });
    
    rexit4.addEventListener('click', event =>{
    recipe4.style.display = "none";
    });
    
    iexit4.addEventListener('click', event =>{
    ingredients4.style.display = "none";
    });
    // BUTTON  END 4
    
    // BUTTON START 5
    btning5.addEventListener('click', event => {
        i5ul1.textContent = "This is philippines ingrediets";
        h2ingredients5.textContent = "Galbi Ingredients";
        ingredients5.style.display = "block";
        recipe5.style.display = "none";
        ingredients5.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
        i5ul1.textContent = "2 lbs beef short ribs";
            i5ul2.textContent = "1/2 cup soy sauce";
            i5ul3.textContent = "1/4 cup water";
            i5ul4.textContent = "4 garlic cloves";
            i5ul5.textContent = "1/4 tsp black pepper";
            i5ul6.textContent = "2 tbsp sesame oil";
        });
    
    btnrec5.addEventListener('click', event => {
        r5ul2.textContent = "This is philippines reci";
        h2recipe5.textContent = "Galbi Recipe";
    recipe5.style.display = "block";
    ingredients5.style.display = "none";
    recipe5.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r5ul1.textContent = "Prepare the Ribs";
    r5ul2.textContent = "Make the Marinade";
    r5ul3.textContent = "Marinate the Ribs";
    r5ul4.textContent = "Cook the Galbi";
    r5ul5.textContent = "Serve";
    
    });
    
    rexit5.addEventListener('click', event =>{
    recipe5.style.display = "none";
    });
    
    iexit5.addEventListener('click', event =>{
    ingredients5.style.display = "none";
    });
    // BUTTON  END 5
    
    // BUTTON START 6
    btning6.addEventListener('click', event => {
        i6ul1.textContent = "This is philippines ingrediets";
        h2ingredients6.textContent = "Hobakjeon Ingredients";
        ingredients6.style.display = "block";
        recipe6.style.display = "none";
        ingredients6.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
            i6ul1.textContent = "1 medium zucchini";
            i6ul2.textContent = "1/2 tsp salt";
            i6ul3.textContent = "1/4 cup all-purpose flour";
            i6ul4.textContent = "1 egg";
            i6ul5.textContent = "2-3 tbsp cooking oil";
        });
    
    btnrec6.addEventListener('click', event => {
        r6ul2.textContent = "This is philippines reci";
        h2recipe6.textContent = "Hobakjeon Recipe";
    recipe6.style.display = "block";
    ingredients6.style.display = "none";
    recipe6.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r6ul1.textContent = "Prepare the Zucchini";
    r6ul2.textContent = "Set Up the Coating";
    r6ul3.textContent = "Coat the Zucchini";
    r6ul4.textContent = "Pan-Fry the Zucchini";
    r6ul5.textContent = "Make the Dipping Sauce";
    r6ul6.textContent = "Serve";
    
    });
    
    rexit6.addEventListener('click', event =>{
    recipe6.style.display = "none";
    });
    
    iexit6.addEventListener('click', event =>{
    ingredients6.style.display = "none";
    });
    // BUTTON  END 6
    
    // BUTTON START 7
    btning7.addEventListener('click', event => {
        i7ul1.textContent = "This is philippines ingrediets";
        h2ingredients7.textContent = "Japchae Ingredients";
        ingredients7.style.display = "block";
        recipe7.style.display = "none";
        ingredients7.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
        i7ul1.textContent = "8 oz dangmyeon";
            i7ul2.textContent = "1 medium onion";
            i7ul3.textContent = "5-6 shiitake mushrooms";
            i7ul4.textContent = "2-3 green onions";
            i7ul5.textContent = "1-2 tbsp sesame seeds";
    
       
        });
    
    btnrec7.addEventListener('click', event => {
        r7ul2.textContent = "This is philippines reci";
        h2recipe7.textContent = "Japchae Recipe";
    recipe7.style.display = "block";
    ingredients7.style.display = "none";
    recipe7.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    r7ul1.textContent = "Prepare the Noodles";
    r7ul2.textContent = "Marinate the Meat";
    r7ul3.textContent = "Stir-Fry the Vegetables";
    r7ul4.textContent = "Cook the Meat";
    r7ul5.textContent = "Mix the Japchae";
    r7ul6.textContent = "Garnish and Serve";
    });
    
    rexit7.addEventListener('click', event =>{
    recipe7.style.display = "none";
    });
    
    iexit7.addEventListener('click', event =>{
    ingredients7.style.display = "none";
    });
    // BUTTON  END 7
    
    // BUTTON START 8
    btning8.addEventListener('click', event => {
        i8ul1.textContent = "This is philippines ingrediets";
        h2ingredients8.textContent = "Tteokguk Ingredients";
        ingredients8.style.display = "block";
        recipe8.style.display = "none";
        ingredients8.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
            i8ul1.textContent = "2 cups thinly sliced rice cakes";
            i8ul2.textContent = "6 cups beef broth";
            i8ul3.textContent = "2 cloves garlic";
            i8ul4.textContent = "1 tbsp sesame oil";
            i8ul5.textContent = "Ground black pepper";
    
        });
    
    btnrec8.addEventListener('click', event => {
        r8ul2.textContent = "This is philippines reci";
        h2recipe8.textContent = "Tteokguk Recipe";
    recipe8.style.display = "block";
    ingredients8.style.display = "none";
    recipe8.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    r8ul1.textContent = "Soak the Rice Cakes";
    r8ul2.textContent = "Prepare the Broth";
    r8ul3.textContent = "Cook the Rice Cakes";
    r8ul4.textContent = "Season the Soup";
    r8ul5.textContent = "Prepare the Egg Garnish";
    r8ul6.textContent = "Assemble the Tteokguk, and Serve";
    });
    
    rexit8.addEventListener('click', event =>{
    recipe8.style.display = "none";
    });
    
    iexit8.addEventListener('click', event =>{
    ingredients8.style.display = "none";
    });
    // BUTTON  END 8
            break; 
 // ---------------------------- KOREA ---------------------------------------//
            
  // ---------------------------- CHINA ---------------------------------------//
        case 'china':
            food1img.src = "images/CHINA/chow-mein.png";
            h21.textContent = "Chow Mein";
            food2img.src = "images/CHINA/Hot-pot.png";
            h22.textContent = "Hot Pot";
            food3img.src = "images/CHINA/Jianbing.png";
            h23.textContent = "Jianbing";
            food4img.src = "images/CHINA/Kung-Pao.png";
            h24.textContent = "Kung Pao";
            food5img.src = "images/CHINA/Mapo-Tofu.png";
            h25.textContent = "Mapo Tofu";
            food6img.src = "images/CHINA/roasted-duck.png";
            h26.textContent = "Roasted Duck";
            food7img.src = "images/CHINA/sour-pork.png";
            h27.textContent = "Sour Pork";
            food8img.src = "images/CHINA/Xiaolongbao.png";
            h28.textContent = "Xialongbao";

              // BUTTON 1
        btning1.addEventListener('click', event => {
            ingredients1.style.display = "block";
            h2ingredients1.textContent = "Chow Mein Ingredients";
            ingredients1.animate([
                {transform: 'scale(1)', opacity: 0.5},
                { transform: 'scale(1.1)', opacity: 1 },
                ],{
                duration: 1000,      
                 easing: 'ease', 
                fill: "forwards",
                });
        
            
            recipe1.style.display = "none";
            //INGREDIENTS
            i1ul1.textContent = "8 oz chow mein noodles";
            i1ul2.textContent = "2 tbsp vegetable oil";
            i1ul3.textContent = "1 onion, sliced";
            i1ul4.textContent = "2 cloves garlic, minced";
            i1ul5.textContent = "1 cup sliced vegetables (carrots, bell peppers, cabbage)";
            i1ul6.textContent = "1 cup cooked chicken, beef, or shrimp";
            
        
            }); 
    
    btnrec1.addEventListener('click', event => {
        recipe1.style.display = "block";
        h2recipe1.textContent = "Chow Mein Recipe";
        ingredients1.style.display = "none";
        recipe1.animate([
            {transform: 'scale(1)', opacity: 0.5},
            { transform: 'scale(1.1)', opacity: 1 },
        ],{
            duration: 1000,      // Animation duration in milliseconds
             easing: 'ease', // Smooth transition
            fill: "forwards",
        });
        // RECIPE
            r1ul1.textContent = "Cook the Noodles";
            r1ul2.textContent = "Sauté Aromatics";
            r1ul3.textContent = "Add Vegetables";
            r1ul4.textContent = "Add Meat and Noodles";
            r1ul5.textContent = "Season";
            r1ul6.textContent = "Garnish and Serve";
        
    });
    
    rexit1.addEventListener('click', event =>{
        recipe1.style.display = "none";
    });
    
    iexit1.addEventListener('click', event =>{
        ingredients1.style.display = "none";
    });
    
    // BUTTON 1
    
     // BUTTON START 2
     btning2.addEventListener('click', event => {
        i2ul1.textContent = "This is philippines ingrediets";
        h2ingredients2.textContent = "Hot Pot Ingredients";
        ingredients2.style.display = "block";
        recipe2.style.display = "none";
        ingredients2.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
        i2ul1.textContent = "8 cups chicken or beef broth";
        i2ul2.textContent = "2 cloves garlic, minced";
        i2ul3.textContent = "1-inch piece ginger, sliced";
        i2ul4.textContent = "2 tbsp soy sauce";
        i2ul5.textContent = "1 tbsp rice vinegar";
    
        });
    
    btnrec2.addEventListener('click', event => {
        r2ul2.textContent = "This is philippines reci";
        h2recipe2.textContent = "Hot Pot Recipe";
    recipe2.style.display = "block";
    ingredients2.style.display = "none";
    recipe2.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r2ul1.textContent = "Prepare the Broth";
    r2ul2.textContent = "Set Up the Hot Pot";
    r2ul3.textContent = "Cook and Enjoy";
    
    });
    
    rexit2.addEventListener('click', event =>{
    recipe2.style.display = "none";
    });
    
    iexit2.addEventListener('click', event =>{
    ingredients2.style.display = "none";
    });
    // BUTTON END 2
    
    
    // BUTTON START 3
    btning3.addEventListener('click', event => {
        i3ul1.textContent = "This is philippines ingrediets";
        ingredients3.style.display = "block";
        h2ingredients3.textContent = "Jianbing Ingredients";
        recipe3.style.display = "none";
        ingredients3.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
        
        i3ul1.textContent = "1 cup all-purpose flour";
            i3ul2.textContent = "1/2 cup water";
            i3ul3.textContent = "2 large eggs";
            i3ul4.textContent = "1/4 cup green onions, chopped";
            i3ul5.textContent = "1/4 cup cilantro, chopped";
    
        });
    
    btnrec3.addEventListener('click', event => {
        r3ul2.textContent = "This is philippines reci";
        h2recipe3.textContent = "Jianbing Recipe";
    recipe3.style.display = "block";
    ingredients3.style.display = "none";
    recipe3.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r3ul1.textContent = "Prepare the Batter";
    r3ul2.textContent = "Cook the Crepe";
    r3ul3.textContent = "Add the Filling";
    r3ul5.textContent = "Fold and Serve";
    r3ul6.textContent = "Serve";
    
    });
    
    rexit3.addEventListener('click', event =>{
    recipe3.style.display = "none";
    });
    
    iexit3.addEventListener('click', event =>{
    ingredients3.style.display = "none";
    });
    // BUTTON  END 3
    
    
    
    // BUTTON START 4
    btning4.addEventListener('click', event => {
        i4ul1.textContent = "This is philippines ingrediets";
        h2ingredients4.textContent = "Kung Pao Ingredients";
        ingredients4.style.display = "block";
        recipe4.style.display = "none";
        ingredients4.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
        i4ul1.textContent = "1 lb chicken breast, diced";
            i4ul2.textContent = "2 tbsp soy sauce";
            i4ul3.textContent = "1 tbsp rice vinegar";
            i4ul4.textContent = "1 tbsp hoisin sauce";
            i4ul5.textContent = "1 tbsp cornstarch";
    
        });
    
    btnrec4.addEventListener('click', event => {
        r4ul2.textContent = "This is philippines reci";
        h2recipe4.textContent = "Kung Pao Recipe";
    recipe4.style.display = "block";
    ingredients4.style.display = "none";
    recipe4.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r4ul1.textContent = "Marinate the Chicken";
    r4ul2.textContent = "Cook the Chicken";
    r4ul3.textContent = "Add Peanuts and Spices";
    r4ul4.textContent = "Serve";
    
    });
    
    rexit4.addEventListener('click', event =>{
    recipe4.style.display = "none";
    });
    
    iexit4.addEventListener('click', event =>{
    ingredients4.style.display = "none";
    });
    // BUTTON  END 4
    
    // BUTTON START 5
    btning5.addEventListener('click', event => {
        i5ul1.textContent = "This is philippines ingrediets";
        h2ingredients5.textContent = "Mapo Tofu Ingredients";
        ingredients5.style.display = "block";
        recipe5.style.display = "none";
        ingredients5.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
        i5ul1.textContent = "1 lb tofu, cubed";
            i5ul2.textContent = "1/2 lb ground pork";
            i5ul3.textContent = "2 tbsp vegetable oil";
            i5ul4.textContent = "2 cloves garlic, minced";
            i5ul5.textContent = "1 tbsp ginger, minced";
        });
    
    btnrec5.addEventListener('click', event => {
        r5ul2.textContent = "This is philippines reci";
        h2recipe5.textContent = "Mapo Tofu Recipe";
    recipe5.style.display = "block";
    ingredients5.style.display = "none";
    recipe5.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r5ul1.textContent = "Sauté Aromatics";
    r5ul2.textContent = "Cook the Pork";
    r5ul3.textContent = "Add Seasonings";
    r5ul4.textContent = "Add Broth and Tofu";
    r5ul5.textContent = "Thicken the Sauce";
    
    });
    
    rexit5.addEventListener('click', event =>{
    recipe5.style.display = "none";
    });
    
    iexit5.addEventListener('click', event =>{
    ingredients5.style.display = "none";
    });
    // BUTTON  END 5
    
    // BUTTON START 6
    btning6.addEventListener('click', event => {
        i6ul1.textContent = "This is philippines ingrediets";
        h2ingredients6.textContent = "Roasted Duck Ingredients";
        ingredients6.style.display = "block";
        recipe6.style.display = "none";
        ingredients6.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
            i6ul1.textContent = "1 whole duck, cleaned";
            i6ul2.textContent = "1/4 cup soy sauce";
            i6ul3.textContent = "1/4 cup hoisin sauce";
            i6ul4.textContent = "2 tbsp honey";
            i6ul5.textContent = "2 tbsp rice vinegar";
        });
    
    btnrec6.addEventListener('click', event => {
        r6ul2.textContent = "This is philippines reci";
        h2recipe6.textContent = "Roasted Duck Recipe";
    recipe6.style.display = "block";
    ingredients6.style.display = "none";
    recipe6.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r6ul1.textContent = "Prepare the Marinade";
    r6ul2.textContent = "Marinate the Duck";
    r6ul3.textContent = "Preheat the Oven";
    r6ul4.textContent = "Roast the Duck";
    r6ul5.textContent = "Rest and Serve";
    
    });
    
    rexit6.addEventListener('click', event =>{
    recipe6.style.display = "none";
    });
    
    iexit6.addEventListener('click', event =>{
    ingredients6.style.display = "none";
    });
    // BUTTON  END 6
    
    // BUTTON START 7
    btning7.addEventListener('click', event => {
        i7ul1.textContent = "This is philippines ingrediets";
        h2ingredients7.textContent = "Sour Pork Ingredients";
        ingredients7.style.display = "block";
        recipe7.style.display = "none";
        ingredients7.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
        i7ul1.textContent = "1 lb pork tenderloin, cubed";
            i7ul2.textContent = "1/2 cup cornstarch";
            i7ul3.textContent = "1/2 cup flour";
            i7ul4.textContent = "1 egg, beaten";
            i7ul5.textContent = "1 cup pineapple chunks";
    
       
        });
    
    btnrec7.addEventListener('click', event => {
        r7ul2.textContent = "This is philippines reci";
        h2recipe7.textContent = "Sour Pork Recipe";
    recipe7.style.display = "block";
    ingredients7.style.display = "none";
    recipe7.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    r7ul1.textContent = "Coat the Pork";
    r7ul2.textContent = "Fry the Pork";
    r7ul3.textContent = "Prepare the Sauce";
    r7ul4.textContent = "Add Vegetables and Pineapple";
    r7ul5.textContent = "Thicken the Sauce";
    r7ul6.textContent = "Combine and Serve";
    });
    
    rexit7.addEventListener('click', event =>{
    recipe7.style.display = "none";
    });
    
    iexit7.addEventListener('click', event =>{
    ingredients7.style.display = "none";
    });
    // BUTTON  END 7
    
    // BUTTON START 8
    btning8.addEventListener('click', event => {
        i8ul1.textContent = "This is philippines ingrediets";
        h2ingredients8.textContent = "Xialongbao Ingredients";
        ingredients8.style.display = "block";
        recipe8.style.display = "none";
        ingredients8.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
            i8ul1.textContent = "2 cups all-purpose flour";
            i8ul2.textContent = "3/4 cup warm water";
            i8ul3.textContent = "1/2 lb ground pork";
            i8ul4.textContent = "1 tbsp soy sauce";
            i8ul5.textContent = "1 tbsp rice wine";
    
        });
    
    btnrec8.addEventListener('click', event => {
        r8ul2.textContent = "This is philippines reci";
        h2recipe8.textContent = "Xialongbao Recipe";
    recipe8.style.display = "block";
    ingredients8.style.display = "none";
    recipe8.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    r8ul1.textContent = "Prepare the Dough";
    r8ul2.textContent = "Prepare the Filling";
    r8ul3.textContent = "Assemble the Dumplings";
    r8ul4.textContent = "Steam the Dumplings";
    r8ul5.textContent = "Serve";
    });
    
    rexit8.addEventListener('click', event =>{
    recipe8.style.display = "none";
    });
    
    iexit8.addEventListener('click', event =>{
    ingredients8.style.display = "none";
    });
    // BUTTON  END 8
            break; 
            
              // ---------------------------- CHINA ---------------------------------------//



                // ---------------------------- ITALY ---------------------------------------//
            case 'italy':
            food1img.src = "images/ITALY/Bruschetta.png";
            h21.textContent = "Bruschetta";
            food2img.src = "images/ITALY/Panzanella.png";
            h22.textContent = "Panzanella";
            food3img.src = "images/ITALY/Pasta-Carbonara.png";
            h23.textContent = "Pasta Carbonara";
            food4img.src = "images/ITALY/pizza-margherita.png";
            h24.textContent = "Pizza Margherita";
            food5img.src = "images/ITALY/Prosciutto.png";
            h25.textContent = "Prosciutto";
            food6img.src = "images/ITALY/risotto.png";
            h26.textContent = "Risotto";
            food7img.src = "images/ITALY/Tiramisu.png";
            h27.textContent = "Tiramisu";
            food8img.src = "images/ITALY/LASAGNA.png";
            h28.textContent = "Lasagna";

             // BUTTON 1
        btning1.addEventListener('click', event => {
            ingredients1.style.display = "block";
            h2ingredients1.textContent = "Bruschetta Ingredients";
            ingredients1.animate([
                {transform: 'scale(1)', opacity: 0.5},
                { transform: 'scale(1.1)', opacity: 1 },
                ],{
                duration: 1000,      
                 easing: 'ease', 
                fill: "forwards",
                });
        
            
            recipe1.style.display = "none";
            //INGREDIENTS
            i1ul1.textContent = "4 ripe tomatoes";
            i1ul2.textContent = "1/4 cup fresh basil";
            i1ul3.textContent = "2-3 cloves garlic";
            i1ul4.textContent = "1 tbsp balsamic vinegar";
            i1ul5.textContent = "Salt";
            i1ul6.textContent = "Black pepper";
            
            
        
            }); 
    
    btnrec1.addEventListener('click', event => {
        recipe1.style.display = "block";
        h2recipe1.textContent = "Bruschetta Recipe";
        ingredients1.style.display = "none";
        recipe1.animate([
            {transform: 'scale(1)', opacity: 0.5},
            { transform: 'scale(1.1)', opacity: 1 },
        ],{
            duration: 1000,      // Animation duration in milliseconds
             easing: 'ease', // Smooth transition
            fill: "forwards",
        });
        // RECIPE
            r1ul1.textContent = "Prepare the Bread";
            r1ul2.textContent = "Make the Topping";
            r1ul3.textContent = "Assemble the Bruschetta";
            r1ul4.textContent = "Serve";
        
    });
    
    rexit1.addEventListener('click', event =>{
        recipe1.style.display = "none";
    });
    
    iexit1.addEventListener('click', event =>{
        ingredients1.style.display = "none";
    });
    
    // BUTTON 1
    
     // BUTTON START 2
     btning2.addEventListener('click', event => {
        i2ul1.textContent = "This is philippines ingrediets";
        h2ingredients2.textContent = "Panzanella Ingredients";
        ingredients2.style.display = "block";
        recipe2.style.display = "none";
        ingredients2.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
        i2ul1.textContent = "4 cups stale bread";
        i2ul2.textContent = "3 ripe tomatoes";
        i2ul3.textContent = "1/4 cup fresh basil";
        i2ul4.textContent = "1-2 tbsp red wine vinegar";
        i2ul5.textContent = "Freshly ground black pepper";
    
        });
    
    btnrec2.addEventListener('click', event => {
        r2ul2.textContent = "This is philippines reci";
        h2recipe2.textContent = "Panzanella Recipe";
    recipe2.style.display = "block";
    ingredients2.style.display = "none";
    recipe2.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r2ul1.textContent = "Prepare the Bread";
    r2ul2.textContent = "Prepare the Vegetables";
    r2ul3.textContent = "Assemble the Salad";
    r2ul4.textContent = "Dress the Salad";
    r2ul5.textContent = "Let It Rest";
    r2ul6.textContent = "Serve";
    
    });
    
    rexit2.addEventListener('click', event =>{
    recipe2.style.display = "none";
    });
    
    iexit2.addEventListener('click', event =>{
    ingredients2.style.display = "none";
    });
    // BUTTON END 2
    
    
    // BUTTON START 3
    btning3.addEventListener('click', event => {
        i3ul1.textContent = "This is philippines ingrediets";
        ingredients3.style.display = "block";
        h2ingredients3.textContent = "Pasta Carbonara Ingredients";
        recipe3.style.display = "none";
        ingredients3.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
        
        i3ul1.textContent = "12 oz pasta";
            i3ul2.textContent = "3 oz guanciale";
            i3ul3.textContent = "2 large eggs";
            i3ul4.textContent = "1/4 cup Parmesan cheese";
            i3ul5.textContent = "Freshly ground black pepper";
            i3ul6.textContent = "Olive oil";
    
        });
    
    btnrec3.addEventListener('click', event => {
        r3ul2.textContent = "This is philippines reci";
        h2recipe3.textContent = "Pasta Carbonara Recipe";
    recipe3.style.display = "block";
    ingredients3.style.display = "none";
    recipe3.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r3ul1.textContent = "Cook the Pasta";
    r3ul2.textContent = "Cook the Guanciale";
    r3ul3.textContent = "Prepare the Egg Mixture";
    r3ul4.textContent = "Combine Pasta and Guanciale";
    r3ul5.textContent = "Create the Carbonara Sauce";
    r3ul6.textContent = "Serve";
    
    });
    
    rexit3.addEventListener('click', event =>{
    recipe3.style.display = "none";
    });
    
    iexit3.addEventListener('click', event =>{
    ingredients3.style.display = "none";
    });
    // BUTTON  END 3
    
    
    
    // BUTTON START 4
    btning4.addEventListener('click', event => {
        i4ul1.textContent = "This is philippines ingrediets";
        h2ingredients4.textContent = "Pizza Margherita Ingredients";
        ingredients4.style.display = "block";
        recipe4.style.display = "none";
        ingredients4.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
        i4ul1.textContent = "2 1/4 tsp active dry yeast";
            i4ul2.textContent = "1 1/4 cups warm water";
            i4ul3.textContent = "3 1/2 cups all-purpose flour";
            i4ul4.textContent = "1 tbsp olive oil";
            i4ul5.textContent = "1 tsp salt";
            i4ul6.textContent = "1 tsp sugar";
    
        });
    
    btnrec4.addEventListener('click', event => {
        r4ul2.textContent = "This is philippines reci";
        h2recipe4.textContent = "Pizza Margherita Recipe";
    recipe4.style.display = "block";
    ingredients4.style.display = "none";
    recipe4.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r4ul1.textContent = "Activate the Yeast";
    r4ul2.textContent = "Make the Dough";
    r4ul3.textContent = "Knead the Dough";
    r4ul4.textContent = "Assemble the Pizza";
    r4ul5.textContent = "Bake the Pizza";
    r4ul6.textContent = "Finish the Pizza, and Serve";
    
    });
    
    rexit4.addEventListener('click', event =>{
    recipe4.style.display = "none";
    });
    
    iexit4.addEventListener('click', event =>{
    ingredients4.style.display = "none";
    });
    // BUTTON  END 4
    
    // BUTTON START 5
    btning5.addEventListener('click', event => {
        i5ul1.textContent = "This is philippines ingrediets";
        h2ingredients5.textContent = "Prosciutto Ingredients";
        ingredients5.style.display = "block";
        recipe5.style.display = "none";
        ingredients5.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
        i5ul1.textContent = "2 slices of good-quality bread";
            i5ul2.textContent = "4-6 slices of prosciutto";
            i5ul3.textContent = "1/2 ball fresh mozzarella, sliced";
            i5ul4.textContent = "Fresh basil leaves";
            i5ul5.textContent = "Olive oil or balsamic glaze";
            i5ul6.textContent = "Salt and pepper";
        });
    
    btnrec5.addEventListener('click', event => {
        r5ul2.textContent = "This is philippines reci";
        h2recipe5.textContent = "Prosciutto Recipe";
    recipe5.style.display = "block";
    ingredients5.style.display = "none";
    recipe5.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r5ul1.textContent = "Toast the bread";
    r5ul2.textContent = "Layer the prosciutto";
    r5ul3.textContent = "Add the mozzarella slices";
    r5ul4.textContent = "Top with fresh basil";
    r5ul5.textContent = "Drizzle with olive oil or balsamic glaze";
    r5ul6.textContent = "Top with the second slice of bread";
    
    });
    
    rexit5.addEventListener('click', event =>{
    recipe5.style.display = "none";
    });
    
    iexit5.addEventListener('click', event =>{
    ingredients5.style.display = "none";
    });
    // BUTTON  END 5
    
    // BUTTON START 6
    btning6.addEventListener('click', event => {
        i6ul1.textContent = "This is philippines ingrediets";
        h2ingredients6.textContent = "Risotto Ingredients";
        ingredients6.style.display = "block";
        recipe6.style.display = "none";
        ingredients6.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
            i6ul1.textContent = "1 1/2 cups Arborio rice";
            i6ul2.textContent = "4 cups chicken or vegetable broth";
            i6ul3.textContent = "1/2 cup dry white wine";
            i6ul4.textContent = "1/2 cup Parmesan cheese, grated";
            i6ul5.textContent = "Salt and pepper";
            i6ul6.textContent = "Fresh herbs";
        });
    
    btnrec6.addEventListener('click', event => {
        r6ul2.textContent = "This is philippines reci";
        h2recipe6.textContent = "Risotto Recipe";
    recipe6.style.display = "block";
    ingredients6.style.display = "none";
    recipe6.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    
    r6ul1.textContent = "Prepare the Broth";
    r6ul2.textContent = "Sauté the Aromatics";
    r6ul3.textContent = "Toast the Rice";
    r6ul4.textContent = "Add the Wine";
    r6ul5.textContent = "Add the Broth Gradually";
    r6ul6.textContent = "Finish the Risotto, and Serve";
    
    });
    
    rexit6.addEventListener('click', event =>{
    recipe6.style.display = "none";
    });
    
    iexit6.addEventListener('click', event =>{
    ingredients6.style.display = "none";
    });
    // BUTTON  END 6
    
    // BUTTON START 7
    btning7.addEventListener('click', event => {
        i7ul1.textContent = "This is philippines ingrediets";
        h2ingredients7.textContent = "Tiramisu Ingredients";
        ingredients7.style.display = "block";
        recipe7.style.display = "none";
        ingredients7.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
        i7ul1.textContent = "1 1/2 cups strong brewed c";
            i7ul2.textContent = "2 tbsp coffee liqueur";
            i7ul3.textContent = "6 large egg yolks";
            i7ul4.textContent = "1 tsp vanilla extract";
            i7ul5.textContent = "1 pack of ladyfingers";
            i7ul6.textContent = "Unsweetened cocoa powder";
    
       
        });
    
    btnrec7.addEventListener('click', event => {
        r7ul2.textContent = "This is philippines reci";
        h2recipe7.textContent = "Tiramisu Recipe";
    recipe7.style.display = "block";
    ingredients7.style.display = "none";
    recipe7.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    r7ul1.textContent = "Prepare the Coffee Mixture";
    r7ul2.textContent = "Make the Mascarpone Mixture";
    r7ul3.textContent = "Whip the Cream";
    r7ul4.textContent = "Combine";
    r7ul5.textContent = "Assemble the Tiramisu";
    r7ul6.textContent = "Chill, and then Serve";
    });
    
    rexit7.addEventListener('click', event =>{
    recipe7.style.display = "none";
    });
    
    iexit7.addEventListener('click', event =>{
    ingredients7.style.display = "none";
    });
    // BUTTON  END 7
    
    // BUTTON START 8
    btning8.addEventListener('click', event => {
        i8ul1.textContent = "This is philippines ingrediets";
        h2ingredients8.textContent = "Lasagna Ingredients";
        ingredients8.style.display = "block";
        recipe8.style.display = "none";
        ingredients8.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
        ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
        });
    
            i8ul1.textContent = "12 lasagna noodles";
            i8ul2.textContent = "2 tbsp olive oil";
            i8ul3.textContent = "3 cloves garlic, minced";
            i8ul4.textContent = "1 (28 oz) can crushed tomatoes";
            i8ul5.textContent = "1/4 tsp black pepper";
            i8ul6.textContent = "1 egg";
    
        });
    
    btnrec8.addEventListener('click', event => {
        r8ul2.textContent = "This is philippines reci";
        h2recipe8.textContent = "Lasagna Recipe";
    recipe8.style.display = "block";
    ingredients8.style.display = "none";
    recipe8.animate([
        {transform: 'scale(1)', opacity: 0.5},
        { transform: 'scale(1.1)', opacity: 1 },
    ],{
        duration: 1000,      // Animation duration in milliseconds
         easing: 'ease', // Smooth transition
        fill: "forwards",
    });
    r8ul1.textContent = "Prepare the Noodles";
    r8ul2.textContent = "Make the Meat Sauce";
    r8ul3.textContent = "Prepare the Ricotta Mixture";
    r8ul4.textContent = "Assemble the Lasagna";
    r8ul5.textContent = "Bake";
    r8ul6.textContent = "Serve";
    });
    
    rexit8.addEventListener('click', event =>{
    recipe8.style.display = "none";
    });
    
    iexit8.addEventListener('click', event =>{
    ingredients8.style.display = "none";
    });
    // BUTTON  END 8
            break; 
             // ---------------------------- ITALY ---------------------------------------//
    }

});


